<?php
/**
 * Database Initialization Script
 * 
 * This script creates all the necessary tables for the Project Management System.
 */

// Include configuration
require_once '../config/config.php';

// Get database connection
$conn = getDBConnection();

// Read SQL schema file
$sql = file_get_contents('../database_schema.sql');

// Execute multi-query SQL
if ($conn->multi_query($sql)) {
    echo "Database tables created successfully.\n";
    
    // Process all result sets to clear them
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->more_results() && $conn->next_result());
} else {
    echo "Error creating database tables: " . $conn->error . "\n";
}

// Close connection
closeDBConnection($conn);
?>
