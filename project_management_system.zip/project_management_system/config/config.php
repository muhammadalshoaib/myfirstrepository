<?php
/**
 * Main Configuration File
 * 
 * This file contains global configuration settings for the Project Management System.
 */

// Application settings
define('APP_NAME', 'Project Management System');
define('APP_URL', 'http://localhost/project_management_system');
define('APP_VERSION', '1.0.0');

// Path settings
define('ROOT_PATH', dirname(__DIR__));
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('API_PATH', ROOT_PATH . '/api');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOADS_PATH', ASSETS_PATH . '/uploads');

// Session settings
define('SESSION_NAME', 'pms_session');
define('SESSION_LIFETIME', 86400); // 24 hours in seconds

// Security settings
define('HASH_COST', 10); // For password hashing

// Error reporting
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Include database configuration
require_once ROOT_PATH . '/config/database.php';

// Start session
session_name(SESSION_NAME);
session_start();

// Create uploads directory if it doesn't exist
if (!file_exists(UPLOADS_PATH)) {
    mkdir(UPLOADS_PATH, 0755, true);
}

// Set timezone
date_default_timezone_set('UTC');
?>
