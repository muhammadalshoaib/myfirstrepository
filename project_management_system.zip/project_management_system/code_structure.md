# Project Management System - Code Structure Documentation

## Overview

This document provides an overview of the code structure for the Project Management System. It explains the organization of directories, key files, and their purposes to help developers understand and maintain the codebase.

## Directory Structure

```
project_management_system/
├── api/                  # API endpoints for frontend-backend communication
│   ├── activity/         # Activity log related endpoints
│   ├── auth/             # Authentication related endpoints
│   ├── dashboard/        # Dashboard data endpoints
│   ├── projects/         # Project management endpoints
│   └── tasks/            # Task management endpoints
├── assets/               # Static assets
│   ├── images/           # Image files
│   └── uploads/          # User uploaded files
├── config/               # Configuration files
├── css/                  # CSS and Less stylesheets
├── includes/             # PHP class files and utilities
├── js/                   # JavaScript files
└── index.php             # Main entry point
```

## Key Files and Their Purpose

### Configuration Files

- **config/config.php**: Main configuration file with application settings
- **config/database.php**: Database connection configuration
- **config/init_database.php**: Script to initialize database tables

### Backend Classes

- **includes/auth.php**: User authentication and session management
- **includes/project.php**: Project management functionality
- **includes/task.php**: Task management functionality
- **includes/user.php**: User management functionality

### API Endpoints

- **api/auth/check.php**: Check authentication status
- **api/auth/login.php**: Handle user login
- **api/auth/logout.php**: Handle user logout
- **api/auth/register.php**: Handle user registration
- **api/dashboard/stats.php**: Get dashboard statistics
- **api/projects/list.php**: Get list of projects with filtering
- **api/projects/create.php**: Create new project
- **api/tasks/list.php**: Get list of tasks with filtering
- **api/tasks/update-status.php**: Update task status

### Frontend Files

- **index.php**: Dashboard page
- **login.php**: Login page
- **register.php**: Registration page
- **projects.php**: Projects listing page
- **tasks.php**: Tasks listing page

### CSS/Less Files

- **css/styles.css**: Compiled CSS styles
- **css/styles.less**: Less source files with variables and mixins

### JavaScript Files

- **js/main.js**: Common JavaScript functions
- **js/dashboard.js**: Dashboard specific functionality
- **js/login.js**: Login page functionality
- **js/register.js**: Registration page functionality
- **js/projects.js**: Projects page functionality
- **js/tasks.js**: Tasks page functionality

## Database Schema

The database consists of the following main tables:

1. **users**: Stores user account information
2. **projects**: Stores project information
3. **project_members**: Maps users to projects with roles
4. **tasks**: Stores task information
5. **task_comments**: Stores comments on tasks
6. **task_attachments**: Stores file attachments for tasks
7. **activity_logs**: Tracks user activity across the system

## Authentication Flow

1. User submits login credentials via login.php
2. Frontend sends credentials to api/auth/login.php
3. Backend validates credentials and creates session
4. Frontend redirects to dashboard on success

## Data Flow

1. Frontend JavaScript makes AJAX requests to API endpoints
2. API endpoints process requests and interact with database
3. API returns JSON responses
4. Frontend updates UI based on responses

## Extension Points

The system is designed to be extensible in the following ways:

1. **New API Endpoints**: Add new files in the api/ directory
2. **New Features**: Add new classes in the includes/ directory
3. **UI Customization**: Modify Less variables in css/styles.less
4. **Additional Reports**: Add new report types in the reports/ directory

## Security Considerations

1. All user inputs are sanitized before database operations
2. Passwords are hashed using PHP's password_hash() function
3. Session management includes protection against session fixation
4. API endpoints verify authentication before processing requests
5. CSRF protection is implemented for form submissions
