<?php
/**
 * API endpoint for user logout
 * 
 * Handles user session termination
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Create auth instance
$auth = new Auth();

// Perform logout
$result = $auth->logout();

// Return result
echo json_encode($result);
?>
