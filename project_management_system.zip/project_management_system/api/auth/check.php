<?php
/**
 * API endpoint for user authentication check
 * 
 * Checks if the user is currently authenticated
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
$isLoggedIn = $auth->isLoggedIn();

if ($isLoggedIn) {
    // Get current user data
    $user = $auth->getCurrentUser();
    
    // Return success response with user data
    echo json_encode([
        'status' => 'success',
        'authenticated' => true,
        'user' => $user
    ]);
} else {
    // Return failure response
    echo json_encode([
        'status' => 'success',
        'authenticated' => false
    ]);
}
?>
