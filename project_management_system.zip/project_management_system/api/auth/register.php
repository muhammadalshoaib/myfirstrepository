<?php
/**
 * API endpoint for user registration
 * 
 * Handles new user registration
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['username']) || empty($data['password']) || empty($data['email']) || empty($data['full_name'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'All fields are required'
    ]);
    exit;
}

// Create auth instance
$auth = new Auth();

// Attempt registration
$result = $auth->register(
    $data['username'],
    $data['password'],
    $data['email'],
    $data['full_name'],
    isset($data['role']) ? $data['role'] : 'member'
);

// Return result
echo json_encode($result);
?>
