<?php
/**
 * API endpoint for project listing
 * 
 * Returns a list of projects with optional filtering
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Include project class
require_once INCLUDES_PATH . '/project.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Create project instance
$project = new Project();

// Get filter parameters
$filters = [];

// Check if minimal data is requested (for dropdowns)
$minimal = isset($_GET['minimal']) && $_GET['minimal'] === 'true';

// Add user_id filter for non-admin users
if (!$auth->hasRole('admin')) {
    $filters['user_id'] = $currentUser['user_id'];
}

// Add other filters if provided
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $filters['status'] = $_GET['status'];
}

if (isset($_GET['owner_id']) && !empty($_GET['owner_id'])) {
    $filters['owner_id'] = (int)$_GET['owner_id'];
}

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $filters['search'] = $_GET['search'];
}

// Get sort parameters
if (isset($_GET['sort_by']) && !empty($_GET['sort_by'])) {
    $filters['sort_by'] = $_GET['sort_by'];
}

// Get pagination parameters
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 12;

// Get projects
$allProjects = $project->getAll($filters);

// Calculate total pages
$totalProjects = count($allProjects);
$totalPages = ceil($totalProjects / $perPage);

// Paginate results
$paginatedProjects = array_slice($allProjects, ($page - 1) * $perPage, $perPage);

// Calculate progress for each project if not minimal
if (!$minimal) {
    $conn = getDBConnection();
    foreach ($paginatedProjects as &$projectData) {
        // Get total tasks
        $stmt = $conn->prepare("
            SELECT COUNT(*) as total_tasks,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks
            FROM tasks
            WHERE project_id = ?
        ");
        $stmt->bind_param("i", $projectData['project_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $taskData = $result->fetch_assoc();
        
        $projectData['total_tasks'] = (int)$taskData['total_tasks'];
        $projectData['completed_tasks'] = (int)$taskData['completed_tasks'];
        
        // Calculate progress percentage
        $projectData['progress'] = $projectData['total_tasks'] > 0 
            ? round(($projectData['completed_tasks'] / $projectData['total_tasks']) * 100) 
            : 0;
    }
    closeDBConnection($conn);
}

// Return projects with pagination info
echo json_encode([
    'status' => 'success',
    'projects' => $paginatedProjects,
    'pagination' => [
        'total' => $totalProjects,
        'per_page' => $perPage,
        'current_page' => $page,
        'total_pages' => $totalPages
    ]
]);
?>
