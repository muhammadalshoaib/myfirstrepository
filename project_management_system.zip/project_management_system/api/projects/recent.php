<?php
/**
 * API endpoint for recent projects
 * 
 * Returns a list of recent projects for the current user
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Include project class
require_once INCLUDES_PATH . '/project.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Create project instance
$project = new Project();

// Get recent projects
$filters = [
    'user_id' => $currentUser['user_id']
];

// Limit to 5 recent projects
$projects = array_slice($project->getAll($filters), 0, 5);

// Calculate progress for each project
$conn = getDBConnection();
foreach ($projects as &$projectData) {
    // Get total tasks
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total_tasks,
               SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks
        FROM tasks
        WHERE project_id = ?
    ");
    $stmt->bind_param("i", $projectData['project_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $taskData = $result->fetch_assoc();
    
    $projectData['total_tasks'] = (int)$taskData['total_tasks'];
    $projectData['completed_tasks'] = (int)$taskData['completed_tasks'];
    
    // Calculate progress percentage
    $projectData['progress'] = $projectData['total_tasks'] > 0 
        ? round(($projectData['completed_tasks'] / $projectData['total_tasks']) * 100) 
        : 0;
}

// Close connection
closeDBConnection($conn);

// Return projects
echo json_encode([
    'status' => 'success',
    'projects' => $projects
]);
?>
