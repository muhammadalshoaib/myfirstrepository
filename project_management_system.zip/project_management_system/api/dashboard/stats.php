<?php
/**
 * API endpoint for dashboard statistics
 * 
 * Returns counts of projects, tasks, completed tasks, and users
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Get database connection
$conn = getDBConnection();

// Initialize stats array
$stats = [
    'projects' => 0,
    'tasks' => 0,
    'completed_tasks' => 0,
    'users' => 0
];

// Get project count
$projectQuery = "SELECT COUNT(*) as count FROM projects";
if (!$auth->hasRole('admin')) {
    $projectQuery .= " WHERE project_id IN (SELECT project_id FROM project_members WHERE user_id = ?)";
    $stmt = $conn->prepare($projectQuery);
    $stmt->bind_param("i", $currentUser['user_id']);
} else {
    $stmt = $conn->prepare($projectQuery);
}
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['projects'] = (int)$row['count'];
}

// Get task count
$taskQuery = "SELECT COUNT(*) as count FROM tasks";
if (!$auth->hasRole('admin')) {
    $taskQuery .= " WHERE project_id IN (SELECT project_id FROM project_members WHERE user_id = ?)";
    $stmt = $conn->prepare($taskQuery);
    $stmt->bind_param("i", $currentUser['user_id']);
} else {
    $stmt = $conn->prepare($taskQuery);
}
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['tasks'] = (int)$row['count'];
}

// Get completed task count
$completedTaskQuery = "SELECT COUNT(*) as count FROM tasks WHERE status = 'completed'";
if (!$auth->hasRole('admin')) {
    $completedTaskQuery .= " AND project_id IN (SELECT project_id FROM project_members WHERE user_id = ?)";
    $stmt = $conn->prepare($completedTaskQuery);
    $stmt->bind_param("i", $currentUser['user_id']);
} else {
    $stmt = $conn->prepare($completedTaskQuery);
}
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['completed_tasks'] = (int)$row['count'];
}

// Get user count
if ($auth->hasRole('admin')) {
    $userQuery = "SELECT COUNT(*) as count FROM users";
    $stmt = $conn->prepare($userQuery);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $stats['users'] = (int)$row['count'];
    }
} else {
    // For non-admin users, count team members from their projects
    $userQuery = "SELECT COUNT(DISTINCT user_id) as count FROM project_members 
                 WHERE project_id IN (SELECT project_id FROM project_members WHERE user_id = ?)";
    $stmt = $conn->prepare($userQuery);
    $stmt->bind_param("i", $currentUser['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $stats['users'] = (int)$row['count'];
    }
}

// Close connection
closeDBConnection($conn);

// Return stats
echo json_encode([
    'status' => 'success',
    'stats' => $stats
]);
?>
