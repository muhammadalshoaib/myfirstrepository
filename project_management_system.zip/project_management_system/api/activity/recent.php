<?php
/**
 * API endpoint for recent activity logs
 * 
 * Returns a list of recent activity logs for the current user's projects
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Get database connection
$conn = getDBConnection();

// Get projects the user is a member of
$projectsQuery = "SELECT project_id FROM project_members WHERE user_id = ?";
$stmt = $conn->prepare($projectsQuery);
$stmt->bind_param("i", $currentUser['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$projectIds = [];
while ($row = $result->fetch_assoc()) {
    $projectIds[] = $row['project_id'];
}

// If user is not a member of any projects, return empty array
if (empty($projectIds)) {
    echo json_encode([
        'status' => 'success',
        'activities' => []
    ]);
    exit;
}

// Get recent activity logs for these projects
$activityQuery = "
    SELECT al.*, u.username, u.full_name
    FROM activity_logs al
    JOIN users u ON al.user_id = u.user_id
    WHERE (al.entity_type = 'project' AND al.entity_id IN (" . implode(',', $projectIds) . "))
       OR (al.entity_type = 'task' AND al.entity_id IN (
           SELECT task_id FROM tasks WHERE project_id IN (" . implode(',', $projectIds) . ")
       ))
    ORDER BY al.created_at DESC
    LIMIT 20
";

$stmt = $conn->prepare($activityQuery);
$stmt->execute();
$result = $stmt->get_result();

$activities = [];
while ($row = $result->fetch_assoc()) {
    $activities[] = $row;
}

// Close connection
closeDBConnection($conn);

// Return activities
echo json_encode([
    'status' => 'success',
    'activities' => $activities
]);
?>
