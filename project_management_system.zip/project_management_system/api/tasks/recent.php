<?php
/**
 * API endpoint for recent tasks
 * 
 * Returns a list of recent tasks for the current user
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Include task class
require_once INCLUDES_PATH . '/task.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Create task instance
$task = new Task();

// Get recent tasks
$filters = [
    'assigned_to' => $currentUser['user_id']
];

// Limit to 10 recent tasks
$tasks = array_slice($task->getAll($filters), 0, 10);

// Return tasks
echo json_encode([
    'status' => 'success',
    'tasks' => $tasks
]);
?>
