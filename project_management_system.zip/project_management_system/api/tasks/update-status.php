<?php
/**
 * API endpoint for updating task status
 * 
 * Handles updating the status of a task
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Include task class
require_once INCLUDES_PATH . '/task.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['task_id']) || empty($data['status'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Task ID and status are required'
    ]);
    exit;
}

// Create task instance
$task = new Task();

// Update task status
$result = $task->update(
    $data['task_id'],
    ['status' => $data['status']],
    $currentUser['user_id']
);

// Return result
echo json_encode($result);
?>
