<?php
/**
 * API endpoint for task listing
 * 
 * Returns a list of tasks with optional filtering
 */

// Include configuration
require_once '../../config/config.php';

// Include auth class
require_once INCLUDES_PATH . '/auth.php';

// Include task class
require_once INCLUDES_PATH . '/task.php';

// Set content type to JSON
header('Content-Type: application/json');

// Create auth instance
$auth = new Auth();

// Check if user is logged in
if (!$auth->isLoggedIn()) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Authentication required'
    ]);
    exit;
}

// Get current user
$currentUser = $auth->getCurrentUser();

// Create task instance
$task = new Task();

// Get filter parameters
$filters = [];

// Add filters if provided
if (isset($_GET['project_id']) && !empty($_GET['project_id'])) {
    $filters['project_id'] = (int)$_GET['project_id'];
}

if (isset($_GET['status']) && !empty($_GET['status'])) {
    $filters['status'] = $_GET['status'];
}

if (isset($_GET['priority']) && !empty($_GET['priority'])) {
    $filters['priority'] = $_GET['priority'];
}

if (isset($_GET['assigned_to']) && $_GET['assigned_to'] === 'me') {
    $filters['assigned_to'] = $currentUser['user_id'];
} elseif (isset($_GET['assigned_to']) && $_GET['assigned_to'] === 'unassigned') {
    $filters['assigned_to'] = null;
} elseif (isset($_GET['assigned_to']) && !empty($_GET['assigned_to'])) {
    $filters['assigned_to'] = (int)$_GET['assigned_to'];
}

if (isset($_GET['due_date_from']) && !empty($_GET['due_date_from'])) {
    $filters['due_date_from'] = $_GET['due_date_from'];
}

if (isset($_GET['due_date_to']) && !empty($_GET['due_date_to'])) {
    $filters['due_date_to'] = $_GET['due_date_to'];
}

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $filters['search'] = $_GET['search'];
}

// Get sort parameters
if (isset($_GET['order_by']) && !empty($_GET['order_by'])) {
    $filters['order_by'] = $_GET['order_by'];
}

if (isset($_GET['order_dir']) && !empty($_GET['order_dir'])) {
    $filters['order_dir'] = $_GET['order_dir'];
}

// Get pagination parameters
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 20;

// Get tasks
$allTasks = $task->getAll($filters);

// Calculate total pages
$totalTasks = count($allTasks);
$totalPages = ceil($totalTasks / $perPage);

// Paginate results
$paginatedTasks = array_slice($allTasks, ($page - 1) * $perPage, $perPage);

// Return tasks with pagination info
echo json_encode([
    'status' => 'success',
    'tasks' => $paginatedTasks,
    'pagination' => [
        'total' => $totalTasks,
        'per_page' => $perPage,
        'current_page' => $page,
        'total_pages' => $totalPages
    ]
]);
?>
