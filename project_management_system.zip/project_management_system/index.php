<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Management System</title>
    <link rel="stylesheet" href="css/styles.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="navbar-brand">Project Management System</a>
            <div class="navbar-nav" id="navbarNav">
                <div class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="projects.php">Projects</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="tasks.php">Tasks</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="users.php">Users</a>
                </div>
                <div class="nav-item" id="userDropdown">
                    <a class="nav-link" href="#"><i class="fas fa-user"></i> <span id="currentUser">User</span></a>
                    <div class="dropdown-menu d-none" id="userMenu">
                        <a href="profile.php">Profile</a>
                        <a href="settings.php">Settings</a>
                        <a href="#" id="logoutBtn">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-3">
                <div class="sidebar">
                    <div class="sidebar-sticky">
                        <h6 class="sidebar-heading">Main Menu</h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="index.php">
                                    <i class="fas fa-home"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="projects.php">
                                    <i class="fas fa-project-diagram"></i> Projects
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="tasks.php">
                                    <i class="fas fa-tasks"></i> Tasks
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="calendar.php">
                                    <i class="fas fa-calendar-alt"></i> Calendar
                                </a>
                            </li>
                        </ul>

                        <h6 class="sidebar-heading mt-4">Management</h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i class="fas fa-users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="reports.php">
                                    <i class="fas fa-chart-bar"></i> Reports
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="settings.php">
                                    <i class="fas fa-cog"></i> Settings
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Main Content Area -->
            <div class="col-9">
                <div class="main-content">
                    <h1 class="mb-4">Dashboard</h1>

                    <!-- Stats Cards -->
                    <div class="dashboard-stats">
                        <div class="stat-card">
                            <i class="fas fa-project-diagram fa-2x text-primary mb-2"></i>
                            <h3 id="projectCount">0</h3>
                            <p>Projects</p>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-tasks fa-2x text-success mb-2"></i>
                            <h3 id="taskCount">0</h3>
                            <p>Tasks</p>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-check-circle fa-2x text-info mb-2"></i>
                            <h3 id="completedTaskCount">0</h3>
                            <p>Completed Tasks</p>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-users fa-2x text-warning mb-2"></i>
                            <h3 id="userCount">0</h3>
                            <p>Team Members</p>
                        </div>
                    </div>

                    <!-- Recent Projects -->
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Recent Projects</h5>
                            <a href="projects.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Project Name</th>
                                            <th>Status</th>
                                            <th>Progress</th>
                                            <th>Due Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="recentProjectsTable">
                                        <!-- Projects will be loaded here via JavaScript -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Tasks -->
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Recent Tasks</h5>
                            <a href="tasks.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="task-list" id="recentTasksList">
                                <!-- Tasks will be loaded here via JavaScript -->
                            </div>
                        </div>
                    </div>

                    <!-- Activity Feed -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Recent Activity</h5>
                        </div>
                        <div class="card-body">
                            <ul class="activity-feed" id="activityFeed">
                                <!-- Activity logs will be loaded here via JavaScript -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">Project Management System &copy; 2025. All rights reserved.</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="js/main.js"></script>
    <script src="js/dashboard.js"></script>
</body>
</html>
