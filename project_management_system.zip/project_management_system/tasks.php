<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks - Project Management System</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="navbar-brand">Project Management System</a>
            <div class="navbar-nav" id="navbarNav">
                <div class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="projects.php">Projects</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link active" href="tasks.php">Tasks</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="users.php">Users</a>
                </div>
                <div class="nav-item" id="userDropdown">
                    <a class="nav-link" href="#"><i class="fas fa-user"></i> <span id="currentUser">User</span></a>
                    <div class="dropdown-menu d-none" id="userMenu">
                        <a href="profile.php">Profile</a>
                        <a href="settings.php">Settings</a>
                        <a href="#" id="logoutBtn">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-3">
                <div class="sidebar">
                    <div class="sidebar-sticky">
                        <h6 class="sidebar-heading">Main Menu</h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">
                                    <i class="fas fa-home"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="projects.php">
                                    <i class="fas fa-project-diagram"></i> Projects
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="tasks.php">
                                    <i class="fas fa-tasks"></i> Tasks
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="calendar.php">
                                    <i class="fas fa-calendar-alt"></i> Calendar
                                </a>
                            </li>
                        </ul>

                        <h6 class="sidebar-heading mt-4">Management</h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i class="fas fa-users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="reports.php">
                                    <i class="fas fa-chart-bar"></i> Reports
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="settings.php">
                                    <i class="fas fa-cog"></i> Settings
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Main Content Area -->
            <div class="col-9">
                <div class="main-content">
                    <div id="alertContainer"></div>
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1>Tasks</h1>
                        <button class="btn btn-primary" id="createTaskBtn">
                            <i class="fas fa-plus"></i> Create Task
                        </button>
                    </div>

                    <!-- Task Filters -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Filters</h5>
                        </div>
                        <div class="card-body">
                            <form id="taskFilterForm" class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="projectFilter">Project</label>
                                        <select class="form-control" id="projectFilter">
                                            <option value="">All Projects</option>
                                            <!-- Projects will be loaded here via JavaScript -->
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="statusFilter">Status</label>
                                        <select class="form-control" id="statusFilter">
                                            <option value="">All Statuses</option>
                                            <option value="to_do">To Do</option>
                                            <option value="in_progress">In Progress</option>
                                            <option value="review">Review</option>
                                            <option value="completed">Completed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="priorityFilter">Priority</label>
                                        <select class="form-control" id="priorityFilter">
                                            <option value="">All Priorities</option>
                                            <option value="low">Low</option>
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                            <option value="urgent">Urgent</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="assigneeFilter">Assignee</label>
                                        <select class="form-control" id="assigneeFilter">
                                            <option value="">All Assignees</option>
                                            <option value="me">Assigned to Me</option>
                                            <option value="unassigned">Unassigned</option>
                                            <!-- Users will be loaded here via JavaScript -->
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="dateRangeFilter">Due Date Range</label>
                                        <div class="d-flex">
                                            <input type="date" class="form-control mr-2" id="startDateFilter" placeholder="From">
                                            <input type="date" class="form-control" id="endDateFilter" placeholder="To">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="searchTask">Search</label>
                                        <input type="text" class="form-control" id="searchTask" placeholder="Search tasks...">
                                    </div>
                                </div>
                                <div class="col-12 text-right">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-filter"></i> Apply Filters
                                    </button>
                                    <button type="button" class="btn btn-secondary" id="resetFiltersBtn">
                                        <i class="fas fa-undo"></i> Reset
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Tasks List -->
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Task List</h5>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary active" id="listViewBtn">
                                    <i class="fas fa-list"></i> List
                                </button>
                                <button type="button" class="btn btn-sm btn-outline-secondary" id="boardViewBtn">
                                    <i class="fas fa-columns"></i> Board
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- List View -->
                            <div id="listView" class="task-list">
                                <!-- Tasks will be loaded here via JavaScript -->
                                <div class="text-center py-5">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="sr-only">Loading...</span>
                                    </div>
                                    <p class="mt-2">Loading tasks...</p>
                                </div>
                            </div>
                            
                            <!-- Board View (hidden by default) -->
                            <div id="boardView" class="d-none">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="task-column">
                                            <h6 class="task-column-header bg-light p-2 rounded">To Do</h6>
                                            <div id="todoTasks" class="task-column-body">
                                                <!-- To Do tasks will be loaded here -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="task-column">
                                            <h6 class="task-column-header bg-light p-2 rounded">In Progress</h6>
                                            <div id="inProgressTasks" class="task-column-body">
                                                <!-- In Progress tasks will be loaded here -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="task-column">
                                            <h6 class="task-column-header bg-light p-2 rounded">Review</h6>
                                            <div id="reviewTasks" class="task-column-body">
                                                <!-- Review tasks will be loaded here -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="task-column">
                                            <h6 class="task-column-header bg-light p-2 rounded">Completed</h6>
                                            <div id="completedTasks" class="task-column-body">
                                                <!-- Completed tasks will be loaded here -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pagination -->
                    <nav aria-label="Tasks pagination" class="mt-4">
                        <ul class="pagination justify-content-center" id="tasksPagination">
                            <!-- Pagination will be generated via JavaScript -->
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Task Modal -->
    <div class="modal" id="createTaskModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Task</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="createTaskForm">
                        <div class="form-group">
                            <label for="taskTitle">Task Title</label>
                            <input type="text" class="form-control" id="taskTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="taskProject">Project</label>
                            <select class="form-control" id="taskProject" required>
                                <option value="">Select Project</option>
                                <!-- Projects will be loaded here via JavaScript -->
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="taskDescription">Description</label>
                            <textarea class="form-control" id="taskDescription" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="taskCategory">Category</label>
                            <select class="form-control" id="taskCategory">
                                <option value="">No Category</option>
                                <!-- Categories will be loaded here via JavaScript -->
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="taskStatus">Status</label>
                                    <select class="form-control" id="taskStatus">
                                        <option value="to_do">To Do</option>
                                        <option value="in_progress">In Progress</option>
                                        <option value="review">Review</option>
                                        <option value="completed">Completed</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="taskPriority">Priority</label>
                                    <select class="form-control" id="taskPriority">
                                        <option value="low">Low</option>
                                        <option value="medium" selected>Medium</option>
                                        <option value="high">High</option>
                                        <option value="urgent">Urgent</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="taskStartDate">Start Date</label>
                                    <input type="date" class="form-control" id="taskStartDate">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="taskDueDate">Due Date</label>
                                    <input type="date" class="form-control" id="taskDueDate">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="taskAssignee">Assignee</label>
                            <select class="form-control" id="taskAssignee">
                                <option value="">Unassigned</option>
                                <!-- Users will be loaded here via JavaScript -->
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="taskEstimatedHours">Estimated Hours</label>
                            <input type="number" class="form-control" id="taskEstimatedHours" min="0" step="0.5">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveTaskBtn">Create Task</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">Project Management System &copy; 2025. All rights reserved.</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="js/main.js"></script>
    <script src="js/tasks.js"></script>
</body>
</html>
