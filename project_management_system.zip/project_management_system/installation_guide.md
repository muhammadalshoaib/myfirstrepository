# Project Management System - Installation Guide

## System Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache, Nginx, etc.)
- Modern web browser (Chrome, Firefox, Safari, Edge)

## Installation Steps

### 1. Database Setup

1. Create a new MySQL database for the project:
   ```sql
   CREATE DATABASE project_management;
   ```

2. Create a database user and grant privileges:
   ```sql
   CREATE USER 'pms_user'@'localhost' IDENTIFIED BY 'your_password';
   GRANT ALL PRIVILEGES ON project_management.* TO 'pms_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. Import the database schema:
   ```bash
   mysql -u pms_user -p project_management < database_schema.sql
   ```

### 2. Application Setup

1. Copy all project files to your web server's document root or a subdirectory.

2. Configure the database connection:
   - Open `config/database.php`
   - Update the database credentials:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'pms_user');
     define('DB_PASS', 'your_password');
     define('DB_NAME', 'project_management');
     ```

3. Configure application settings:
   - Open `config/config.php`
   - Update the application URL to match your server:
     ```php
     define('APP_URL', 'http://your-domain.com/project_management_system');
     ```

4. Set appropriate permissions:
   ```bash
   chmod 755 -R /path/to/project_management_system
   chmod 777 -R /path/to/project_management_system/assets/uploads
   ```

5. Initialize the database tables:
   - Access `config/init_database.php` through your web browser or run via command line:
     ```bash
     php config/init_database.php
     ```

### 3. First-time Setup

1. Create an admin user:
   - Access the registration page at `http://your-domain.com/project_management_system/register.php`
   - Register the first user, which will automatically be assigned admin privileges

2. Log in with the newly created admin account

3. Start creating projects and adding users to your system

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify database credentials in `config/database.php`
   - Ensure MySQL service is running
   - Check if the database and user exist with proper privileges

2. **Permission Issues**
   - Ensure web server has read/write permissions to the project directory
   - The uploads directory must be writable by the web server

3. **Blank Page or PHP Errors**
   - Check PHP error logs
   - Enable error reporting in `config/config.php` by setting:
     ```php
     ini_set('display_errors', 1);
     error_reporting(E_ALL);
     ```

4. **Login Issues**
   - Verify session configuration in `config/config.php`
   - Ensure cookies are enabled in your browser

## Support

For additional support or questions, please contact the system administrator.
