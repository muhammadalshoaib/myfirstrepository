// Main JavaScript file for Project Management System

// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize user dropdown
    initUserDropdown();
    
    // Check authentication
    checkAuth();
    
    // Initialize logout functionality
    initLogout();
});

/**
 * Initialize user dropdown menu
 */
function initUserDropdown() {
    const userDropdown = document.getElementById('userDropdown');
    const userMenu = document.getElementById('userMenu');
    
    if (userDropdown && userMenu) {
        userDropdown.addEventListener('click', function(e) {
            e.preventDefault();
            userMenu.classList.toggle('d-none');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!userDropdown.contains(e.target)) {
                userMenu.classList.add('d-none');
            }
        });
    }
}

/**
 * Check if user is authenticated
 */
function checkAuth() {
    fetch('api/auth/check.php')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.authenticated) {
                // User is logged in
                updateUserInfo(data.user);
            } else {
                // User is not logged in, redirect to login page
                window.location.href = 'login.php';
            }
        })
        .catch(error => {
            console.error('Authentication check failed:', error);
            // Redirect to login page on error
            window.location.href = 'login.php';
        });
}

/**
 * Update user information in the UI
 */
function updateUserInfo(user) {
    const currentUserElement = document.getElementById('currentUser');
    if (currentUserElement && user) {
        currentUserElement.textContent = user.username;
    }
}

/**
 * Initialize logout functionality
 */
function initLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            fetch('api/auth/logout.php', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Redirect to login page
                    window.location.href = 'login.php';
                } else {
                    showAlert('Logout failed: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Logout failed:', error);
                showAlert('Logout failed due to an error', 'danger');
            });
        });
    }
}

/**
 * Show alert message
 * 
 * @param {string} message - Alert message
 * @param {string} type - Alert type (success, danger, warning, info)
 * @param {string} containerId - ID of container to append alert to
 */
function showAlert(message, type = 'info', containerId = 'alertContainer') {
    const container = document.getElementById(containerId);
    
    if (!container) {
        // Create alert container if it doesn't exist
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            const newContainer = document.createElement('div');
            newContainer.id = containerId;
            mainContent.insertBefore(newContainer, mainContent.firstChild);
            showAlert(message, type, containerId);
            return;
        } else {
            console.error('Cannot find main content to add alert');
            return;
        }
    }
    
    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.role = 'alert';
    
    // Add message
    alert.innerHTML = `
        ${message}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    `;
    
    // Add to container
    container.appendChild(alert);
    
    // Add event listener to close button
    const closeButton = alert.querySelector('.close');
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            alert.remove();
        });
    }
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.remove();
        }
    }, 5000);
}

/**
 * Format date for display
 * 
 * @param {string} dateString - Date string from API
 * @returns {string} Formatted date string
 */
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

/**
 * Create HTML element with attributes and content
 * 
 * @param {string} tag - HTML tag name
 * @param {object} attributes - HTML attributes
 * @param {string|HTMLElement|Array} content - Element content
 * @returns {HTMLElement} Created element
 */
function createElement(tag, attributes = {}, content = '') {
    const element = document.createElement(tag);
    
    // Set attributes
    for (const key in attributes) {
        element.setAttribute(key, attributes[key]);
    }
    
    // Set content
    if (typeof content === 'string') {
        element.textContent = content;
    } else if (content instanceof HTMLElement) {
        element.appendChild(content);
    } else if (Array.isArray(content)) {
        content.forEach(item => {
            if (typeof item === 'string') {
                element.appendChild(document.createTextNode(item));
            } else if (item instanceof HTMLElement) {
                element.appendChild(item);
            }
        });
    }
    
    return element;
}

/**
 * Make API request
 * 
 * @param {string} endpoint - API endpoint
 * @param {object} options - Fetch options
 * @returns {Promise} Fetch promise
 */
function apiRequest(endpoint, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    
    const fetchOptions = { ...defaultOptions, ...options };
    
    return fetch(`api/${endpoint}`, fetchOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        });
}
