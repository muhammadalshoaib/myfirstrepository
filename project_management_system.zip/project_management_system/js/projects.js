// Projects page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize user dropdown
    initUserDropdown();
    
    // Check authentication
    checkAuth();
    
    // Load projects
    loadProjects();
    
    // Initialize project filters
    initProjectFilters();
    
    // Initialize create project modal
    initCreateProjectModal();
});

/**
 * Load projects with optional filters
 * 
 * @param {object} filters - Optional filters
 * @param {number} page - Page number
 */
function loadProjects(filters = {}, page = 1) {
    // Show loading spinner
    document.getElementById('projectsList').innerHTML = `
        <div class="col-12 text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Loading...</span>
            </div>
            <p class="mt-2">Loading projects...</p>
        </div>
    `;
    
    // Build query string
    let queryParams = new URLSearchParams();
    queryParams.append('page', page);
    
    for (const key in filters) {
        if (filters[key]) {
            queryParams.append(key, filters[key]);
        }
    }
    
    // Fetch projects
    fetch(`api/projects/list.php?${queryParams.toString()}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                displayProjects(data.projects);
                
                // Update pagination
                if (data.pagination) {
                    updatePagination(data.pagination, filters);
                }
            } else {
                showAlert(data.message || 'Failed to load projects', 'danger');
                document.getElementById('projectsList').innerHTML = `
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-exclamation-circle fa-3x text-danger mb-3"></i>
                        <p>Failed to load projects. Please try again.</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading projects:', error);
            showAlert('An error occurred while loading projects', 'danger');
            document.getElementById('projectsList').innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="fas fa-exclamation-circle fa-3x text-danger mb-3"></i>
                    <p>Failed to load projects. Please try again.</p>
                </div>
            `;
        });
}

/**
 * Display projects in the UI
 * 
 * @param {Array} projects - Array of project objects
 */
function displayProjects(projects) {
    const projectsList = document.getElementById('projectsList');
    
    // Clear projects list
    projectsList.innerHTML = '';
    
    if (projects && projects.length > 0) {
        // Add projects to list
        projects.forEach(project => {
            const projectCard = document.createElement('div');
            projectCard.className = 'col-md-6 col-lg-4 mb-4';
            
            // Calculate progress percentage
            const progress = project.progress || 0;
            
            // Format dates
            const startDate = formatDate(project.start_date);
            const endDate = formatDate(project.end_date);
            
            // Create status badge class
            const statusClass = `status-${project.status.replace('_', '-')}`;
            const statusText = project.status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
            
            projectCard.innerHTML = `
                <div class="card project-card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">${project.name}</h5>
                        <span class="project-status ${statusClass}">${statusText}</span>
                    </div>
                    <div class="card-body">
                        <p class="card-text">${project.description || 'No description provided.'}</p>
                        
                        <div class="mb-3">
                            <small class="text-muted">Progress:</small>
                            <div class="progress mt-1" style="height: 5px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: ${progress}%;" 
                                    aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="d-flex justify-content-between mt-1">
                                <small class="text-muted">${progress}% Complete</small>
                                <small class="text-muted">${project.completed_tasks || 0}/${project.total_tasks || 0} Tasks</small>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <div>
                                <small class="text-muted">Start Date:</small>
                                <p class="mb-0">${startDate}</p>
                            </div>
                            <div>
                                <small class="text-muted">End Date:</small>
                                <p class="mb-0">${endDate}</p>
                            </div>
                        </div>
                        
                        <div>
                            <small class="text-muted">Owner:</small>
                            <p class="mb-0">${project.owner_name || 'Unknown'}</p>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between">
                            <a href="project-details.php?id=${project.project_id}" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i> View
                            </a>
                            <div>
                                <a href="edit-project.php?id=${project.project_id}" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <button class="btn btn-sm btn-danger delete-project-btn" data-project-id="${project.project_id}">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            projectsList.appendChild(projectCard);
        });
        
        // Initialize delete buttons
        initDeleteProjectButtons();
    } else {
        // No projects
        projectsList.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                <p>No projects found. Create a new project to get started.</p>
                <button class="btn btn-primary mt-2" id="noProjectsCreateBtn">
                    <i class="fas fa-plus"></i> Create Project
                </button>
            </div>
        `;
        
        // Initialize create button
        const noProjectsCreateBtn = document.getElementById('noProjectsCreateBtn');
        if (noProjectsCreateBtn) {
            noProjectsCreateBtn.addEventListener('click', function() {
                openCreateProjectModal();
            });
        }
    }
}

/**
 * Update pagination controls
 * 
 * @param {object} pagination - Pagination data
 * @param {object} filters - Current filters
 */
function updatePagination(pagination, filters) {
    const paginationElement = document.getElementById('projectsPagination');
    if (!paginationElement) return;
    
    // Clear pagination
    paginationElement.innerHTML = '';
    
    // Previous page button
    const prevLi = document.createElement('li');
    prevLi.className = `page-item ${pagination.current_page === 1 ? 'disabled' : ''}`;
    
    const prevLink = document.createElement('a');
    prevLink.className = 'page-link';
    prevLink.href = '#';
    prevLink.innerHTML = '&laquo;';
    prevLink.setAttribute('aria-label', 'Previous');
    
    if (pagination.current_page > 1) {
        prevLink.addEventListener('click', function(e) {
            e.preventDefault();
            loadProjects(filters, pagination.current_page - 1);
        });
    }
    
    prevLi.appendChild(prevLink);
    paginationElement.appendChild(prevLi);
    
    // Page numbers
    for (let i = 1; i <= pagination.total_pages; i++) {
        const pageLi = document.createElement('li');
        pageLi.className = `page-item ${i === pagination.current_page ? 'active' : ''}`;
        
        const pageLink = document.createElement('a');
        pageLink.className = 'page-link';
        pageLink.href = '#';
        pageLink.textContent = i;
        
        if (i !== pagination.current_page) {
            pageLink.addEventListener('click', function(e) {
                e.preventDefault();
                loadProjects(filters, i);
            });
        }
        
        pageLi.appendChild(pageLink);
        paginationElement.appendChild(pageLi);
    }
    
    // Next page button
    const nextLi = document.createElement('li');
    nextLi.className = `page-item ${pagination.current_page === pagination.total_pages ? 'disabled' : ''}`;
    
    const nextLink = document.createElement('a');
    nextLink.className = 'page-link';
    nextLink.href = '#';
    nextLink.innerHTML = '&raquo;';
    nextLink.setAttribute('aria-label', 'Next');
    
    if (pagination.current_page < pagination.total_pages) {
        nextLink.addEventListener('click', function(e) {
            e.preventDefault();
            loadProjects(filters, pagination.current_page + 1);
        });
    }
    
    nextLi.appendChild(nextLink);
    paginationElement.appendChild(nextLi);
}

/**
 * Initialize project filters
 */
function initProjectFilters() {
    const filterForm = document.getElementById('projectFilterForm');
    const resetFiltersBtn = document.getElementById('resetFiltersBtn');
    
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get filter values
            const status = document.getElementById('statusFilter').value;
            const sortBy = document.getElementById('sortBy').value;
            const search = document.getElementById('searchProject').value;
            
            // Apply filters
            loadProjects({
                status: status,
                sort_by: sortBy,
                search: search
            });
        });
    }
    
    if (resetFiltersBtn) {
        resetFiltersBtn.addEventListener('click', function() {
            // Reset form
            document.getElementById('statusFilter').value = '';
            document.getElementById('sortBy').value = 'created_at';
            document.getElementById('searchProject').value = '';
            
            // Load projects without filters
            loadProjects();
        });
    }
}

/**
 * Initialize create project modal
 */
function initCreateProjectModal() {
    const createProjectBtn = document.getElementById('createProjectBtn');
    const saveProjectBtn = document.getElementById('saveProjectBtn');
    const createProjectModal = document.getElementById('createProjectModal');
    const closeButtons = createProjectModal.querySelectorAll('[data-dismiss="modal"]');
    
    // Open modal
    if (createProjectBtn) {
        createProjectBtn.addEventListener('click', function() {
            openCreateProjectModal();
        });
    }
    
    // Close modal
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            createProjectModal.style.display = 'none';
        });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === createProjectModal) {
            createProjectModal.style.display = 'none';
        }
    });
    
    // Save project
    if (saveProjectBtn) {
        saveProjectBtn.addEventListener('click', function() {
            saveProject();
        });
    }
}

/**
 * Open create project modal
 */
function openCreateProjectModal() {
    const createProjectModal = document.getElementById('createProjectModal');
    const createProjectForm = document.getElementById('createProjectForm');
    
    // Reset form
    if (createProjectForm) {
        createProjectForm.reset();
    }
    
    // Set default values
    document.getElementById('projectStatus').value = 'planning';
    
    // Set today as default start date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('projectStartDate').value = today;
    
    // Show modal
    createProjectModal.style.display = 'block';
}

/**
 * Save new project
 */
function saveProject() {
    // Get form values
    const name = document.getElementById('projectName').value;
    const description = document.getElementById('projectDescription').value;
    const startDate = document.getElementById('projectStartDate').value;
    const endDate = document.getElementById('projectEndDate').value;
    const status = document.getElementById('projectStatus').value;
    
    // Validate form
    if (!name) {
        showAlert('Project name is required', 'warning');
        return;
    }
    
    // Create project data
    const projectData = {
        name: name,
        description: description,
        start_date: startDate,
        end_date: endDate,
        status: status
    };
    
    // Send request
    fetch('api/projects/create.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(projectData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Close modal
            document.getElementById('createProjectModal').style.display = 'none';
            
            // Show success message
            showAlert('Project created successfully', 'success');
            
            // Reload projects
            loadProjects();
        } else {
            showAlert(data.message || 'Failed to create project', 'danger');
        }
    })
    .catch(error => {
        console.error('Error creating project:', error);
        showAlert('An error occurred while creating the project', 'danger');
    });
}

/**
 * Initialize delete project buttons
 */
function initDeleteProjectButtons() {
    const deleteButtons = document.querySelectorAll('.delete-project-btn');
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const projectId = this.getAttribute('data-project-id');
            
            if (confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
                deleteProject(projectId);
            }
        });
    });
}

/**
 * Delete project
 * 
 * @param {number} projectId - Project ID
 */
function deleteProject(projectId) {
    fetch(`api/projects/delete.php`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            project_id: projectId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert('Project deleted successfully', 'success');
            loadProjects();
        } else {
            showAlert(data.message || 'Failed to delete project', 'danger');
        }
    })
    .catch(error => {
        console.error('Error deleting project:', error);
        showAlert('An error occurred while deleting the project', 'danger');
    });
}
