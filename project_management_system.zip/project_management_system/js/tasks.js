// Tasks page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize user dropdown
    initUserDropdown();
    
    // Check authentication
    checkAuth();
    
    // Load projects for filter dropdown
    loadProjectsForDropdown();
    
    // Load users for assignee dropdown
    loadUsersForDropdown();
    
    // Load tasks
    loadTasks();
    
    // Initialize task filters
    initTaskFilters();
    
    // Initialize view toggle
    initViewToggle();
    
    // Initialize create task modal
    initCreateTaskModal();
});

/**
 * Load projects for dropdown
 */
function loadProjectsForDropdown() {
    fetch('api/projects/list.php?minimal=true')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                populateProjectDropdowns(data.projects);
            } else {
                console.error('Failed to load projects:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading projects:', error);
        });
}

/**
 * Populate project dropdowns
 * 
 * @param {Array} projects - Array of project objects
 */
function populateProjectDropdowns(projects) {
    const projectFilter = document.getElementById('projectFilter');
    const taskProject = document.getElementById('taskProject');
    
    if (projects && projects.length > 0) {
        // Add projects to filter dropdown
        if (projectFilter) {
            projects.forEach(project => {
                const option = document.createElement('option');
                option.value = project.project_id;
                option.textContent = project.name;
                projectFilter.appendChild(option);
            });
        }
        
        // Add projects to create task form
        if (taskProject) {
            projects.forEach(project => {
                const option = document.createElement('option');
                option.value = project.project_id;
                option.textContent = project.name;
                taskProject.appendChild(option);
            });
        }
    }
}

/**
 * Load users for dropdown
 */
function loadUsersForDropdown() {
    fetch('api/users/list.php?minimal=true')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                populateUserDropdowns(data.users);
            } else {
                console.error('Failed to load users:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading users:', error);
        });
}

/**
 * Populate user dropdowns
 * 
 * @param {Array} users - Array of user objects
 */
function populateUserDropdowns(users) {
    const assigneeFilter = document.getElementById('assigneeFilter');
    const taskAssignee = document.getElementById('taskAssignee');
    
    if (users && users.length > 0) {
        // Add users to filter dropdown
        if (assigneeFilter) {
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user.user_id;
                option.textContent = user.full_name || user.username;
                assigneeFilter.appendChild(option);
            });
        }
        
        // Add users to create task form
        if (taskAssignee) {
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user.user_id;
                option.textContent = user.full_name || user.username;
                taskAssignee.appendChild(option);
            });
        }
    }
}

/**
 * Load tasks with optional filters
 * 
 * @param {object} filters - Optional filters
 * @param {number} page - Page number
 */
function loadTasks(filters = {}, page = 1) {
    // Show loading spinner
    document.getElementById('listView').innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Loading...</span>
            </div>
            <p class="mt-2">Loading tasks...</p>
        </div>
    `;
    
    // Clear board view columns
    document.getElementById('todoTasks').innerHTML = '';
    document.getElementById('inProgressTasks').innerHTML = '';
    document.getElementById('reviewTasks').innerHTML = '';
    document.getElementById('completedTasks').innerHTML = '';
    
    // Build query string
    let queryParams = new URLSearchParams();
    queryParams.append('page', page);
    
    for (const key in filters) {
        if (filters[key]) {
            queryParams.append(key, filters[key]);
        }
    }
    
    // Fetch tasks
    fetch(`api/tasks/list.php?${queryParams.toString()}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                displayTasks(data.tasks);
                
                // Update pagination
                if (data.pagination) {
                    updatePagination(data.pagination, filters);
                }
            } else {
                showAlert(data.message || 'Failed to load tasks', 'danger');
                document.getElementById('listView').innerHTML = `
                    <div class="text-center py-5">
                        <i class="fas fa-exclamation-circle fa-3x text-danger mb-3"></i>
                        <p>Failed to load tasks. Please try again.</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading tasks:', error);
            showAlert('An error occurred while loading tasks', 'danger');
            document.getElementById('listView').innerHTML = `
                <div class="text-center py-5">
                    <i class="fas fa-exclamation-circle fa-3x text-danger mb-3"></i>
                    <p>Failed to load tasks. Please try again.</p>
                </div>
            `;
        });
}

/**
 * Display tasks in the UI
 * 
 * @param {Array} tasks - Array of task objects
 */
function displayTasks(tasks) {
    const listView = document.getElementById('listView');
    const todoTasks = document.getElementById('todoTasks');
    const inProgressTasks = document.getElementById('inProgressTasks');
    const reviewTasks = document.getElementById('reviewTasks');
    const completedTasks = document.getElementById('completedTasks');
    
    // Clear list view
    listView.innerHTML = '';
    
    if (tasks && tasks.length > 0) {
        // Add tasks to list view
        tasks.forEach(task => {
            const taskItem = createTaskItem(task);
            listView.appendChild(taskItem);
            
            // Add to board view based on status
            const boardTaskItem = createTaskItem(task, true);
            
            switch (task.status) {
                case 'to_do':
                    todoTasks.appendChild(boardTaskItem);
                    break;
                case 'in_progress':
                    inProgressTasks.appendChild(boardTaskItem);
                    break;
                case 'review':
                    reviewTasks.appendChild(boardTaskItem);
                    break;
                case 'completed':
                    completedTasks.appendChild(boardTaskItem);
                    break;
            }
        });
        
        // Initialize task checkboxes
        initTaskCheckboxes();
    } else {
        // No tasks
        listView.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                <p>No tasks found. Create a new task to get started.</p>
                <button class="btn btn-primary mt-2" id="noTasksCreateBtn">
                    <i class="fas fa-plus"></i> Create Task
                </button>
            </div>
        `;
        
        // Initialize create button
        const noTasksCreateBtn = document.getElementById('noTasksCreateBtn');
        if (noTasksCreateBtn) {
            noTasksCreateBtn.addEventListener('click', function() {
                openCreateTaskModal();
            });
        }
        
        // Empty board view columns
        todoTasks.innerHTML = '<div class="text-center p-3 text-muted">No tasks</div>';
        inProgressTasks.innerHTML = '<div class="text-center p-3 text-muted">No tasks</div>';
        reviewTasks.innerHTML = '<div class="text-center p-3 text-muted">No tasks</div>';
        completedTasks.innerHTML = '<div class="text-center p-3 text-muted">No tasks</div>';
    }
}

/**
 * Create task item element
 * 
 * @param {object} task - Task object
 * @param {boolean} forBoard - Whether the item is for board view
 * @returns {HTMLElement} Task item element
 */
function createTaskItem(task, forBoard = false) {
    const taskItem = document.createElement('div');
    taskItem.className = 'task-item';
    if (forBoard) {
        taskItem.className += ' mb-2';
    }
    
    // Checkbox
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'task-checkbox';
    checkbox.checked = task.status === 'completed';
    checkbox.dataset.taskId = task.task_id;
    
    // Task title
    const title = document.createElement('div');
    title.className = `task-title ${task.status === 'completed' ? 'completed' : ''}`;
    
    const titleLink = document.createElement('a');
    titleLink.href = `task-details.php?id=${task.task_id}`;
    titleLink.textContent = task.title;
    
    title.appendChild(titleLink);
    
    // Project badge (only in list view)
    if (!forBoard) {
        const projectBadge = document.createElement('span');
        projectBadge.className = 'badge badge-info ml-2';
        projectBadge.textContent = task.project_name;
        title.appendChild(projectBadge);
    }
    
    // Priority
    const priority = document.createElement('div');
    priority.className = `task-priority priority-${task.priority}`;
    priority.innerHTML = `<i class="fas fa-flag"></i> ${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}`;
    
    // Due date
    const dueDate = document.createElement('div');
    dueDate.className = 'task-due-date';
    dueDate.innerHTML = `<i class="far fa-calendar-alt"></i> ${formatDate(task.due_date)}`;
    
    // Actions
    const actions = document.createElement('div');
    actions.className = 'task-actions';
    
    const viewBtn = document.createElement('a');
    viewBtn.href = `task-details.php?id=${task.task_id}`;
    viewBtn.className = 'btn btn-sm btn-info';
    viewBtn.innerHTML = '<i class="fas fa-eye"></i>';
    viewBtn.title = 'View Task';
    
    const editBtn = document.createElement('a');
    editBtn.href = `edit-task.php?id=${task.task_id}`;
    editBtn.className = 'btn btn-sm btn-warning';
    editBtn.innerHTML = '<i class="fas fa-edit"></i>';
    editBtn.title = 'Edit Task';
    
    actions.appendChild(viewBtn);
    actions.appendChild(editBtn);
    
    // Append all elements to task item
    taskItem.appendChild(checkbox);
    taskItem.appendChild(title);
    
    // For board view, make it more compact
    if (forBoard) {
        const metaInfo = document.createElement('div');
        metaInfo.className = 'd-flex justify-content-between align-items-center mt-2';
        metaInfo.appendChild(priority);
        metaInfo.appendChild(dueDate);
        
        taskItem.appendChild(metaInfo);
    } else {
        taskItem.appendChild(priority);
        taskItem.appendChild(dueDate);
    }
    
    taskItem.appendChild(actions);
    
    return taskItem;
}

/**
 * Initialize task checkboxes
 */
function initTaskCheckboxes() {
    const checkboxes = document.querySelectorAll('.task-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const taskId = this.dataset.taskId;
            const newStatus = this.checked ? 'completed' : 'in_progress';
            
            updateTaskStatus(taskId, newStatus);
        });
    });
}

/**
 * Update task status
 * 
 * @param {number} taskId - Task ID
 * @param {string} status - New status
 */
function updateTaskStatus(taskId, status) {
    fetch('api/tasks/update-status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            task_id: taskId,
            status: status
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showAlert('Task status updated successfully', 'success');
            
            // Reload tasks
            const filters = getActiveFilters();
            loadTasks(filters);
        } else {
            showAlert(data.message || 'Failed to update task status', 'danger');
        }
    })
    .catch(error => {
        console.error('Error updating task status:', error);
        showAlert('An error occurred while updating task status', 'danger');
    });
}

/**
 * Update pagination controls
 * 
 * @param {object} pagination - Pagination data
 * @param {object} filters - Current filters
 */
function updatePagination(pagination, filters) {
    const paginationElement = document.getElementById('tasksPagination');
    if (!paginationElement) return;
    
    // Clear pagination
    paginationElement.innerHTML = '';
    
    // Previous page button
    const prevLi = document.createElement('li');
    prevLi.className = `page-item ${pagination.current_page === 1 ? 'disabled' : ''}`;
    
    const prevLink = document.createElement('a');
    prevLink.className = 'page-link';
    prevLink.href = '#';
    prevLink.innerHTML = '&laquo;';
    prevLink.setAttribute('aria-label', 'Previous');
    
    if (pagination.current_page > 1) {
        prevLink.addEventListener('click', function(e) {
            e.preventDefault();
            loadTasks(filters, pagination.current_page - 1);
        });
    }
    
    prevLi.appendChild(prevLink);
    paginationElement.appendChild(prevLi);
    
    // Page numbers
    for (let i = 1; i <= pagination.total_pages; i++) {
        const pageLi = document.createElement('li');
        pageLi.className = `page-item ${i === pagination.current_page ? 'active' : ''}`;
        
        const pageLink = document.createElement('a');
        pageLink.className = 'page-link';
        pageLink.href = '#';
        pageLink.textContent = i;
        
        if (i !== pagination.current_page) {
            pageLink.addEventListener('click', function(e) {
                e.preventDefault();
                loadTasks(filters, i);
            });
        }
        
        pageLi.appendChild(pageLink);
        paginationElement.appendChild(pageLi);
    }
    
    // Next page button
    const nextLi = document.createElement('li');
    nextLi.className = `page-item ${pagination.current_page === pagination.total_pages ? 'disabled' : ''}`;
    
    const nextLink = document.createElement('a');
    nextLink.className = 'page-link';
    nextLink.href = '#';
    nextLink.innerHTML = '&raquo;';
    nextLink.setAttribute('aria-label', 'Next');
    
    if (pagination.current_page < pagination.total_pages) {
        nextLink.addEventListener('click', function(e) {
            e.preventDefault();
            loadTasks(filters, pagination.current_page + 1);
        });
    }
    
    nextLi.appendChild(nextLink);
    paginationElement.appendChild(nextLi);
}

/**
 * Initialize task filters
 */
function initTaskFilters() {
    const filterForm = document.getElementById('taskFilterForm');
    const resetFiltersBtn = document.getElementById('resetFiltersBtn');
    
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const filters = getActiveFilters();
            loadTasks(filters);
        });
    }
    
    if (resetFiltersBtn) {
        resetFiltersBtn.addEventListener('click', function() {
            // Reset form
            document.getElementById('projectFilter').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('priorityFilter').value = '';
            document.getElementById('assigneeFilter').value = '';
            document.getElementById('startDateFilter').value = '';
            document.getElementById('endDateFilter').value = '';
            document.getElementById('searchTask').value = '';
            
            // Load tasks without filters
            loadTasks();
        });
    }
}

/**
 * Get active filters from form
 * 
 * @returns {object} Filter values
 */
function getActiveFilters() {
    return {
        project_id: document.getElementById('projectFilter').value,
        status: document.getElementById('statusFilter').value,
        priority: document.getElementById('priorityFilter').value,
        assigned_to: document.getElementById('assigneeFilter').value,
        due_date_from: document.getElementById('startDateFilter').value,
        due_date_to: document.getElementById('endDateFilter').value,
        search: document.getElementById('searchTask').value
    };
}

/**
 * Initialize view toggle
 */
function initViewToggle() {
    const listViewBtn = document.getElementById('listViewBtn');
    const boardViewBtn = document.getElementById('boardViewBtn');
    const listView = document.getElementById('listView');
    const boardView = document.getElementById('boardView');
    
    if (listViewBtn && boardViewBtn) {
        listViewBtn.addEventListener('click', function() {
            listViewBtn.classList.add('active');
            boardViewBtn.classList.remove('active');
            listView.classList.remove('d-none');
            boardView.classList.add('d-none');
        });
        
        boardViewBtn.addEventListener('click', function() {
            boardViewBtn.classList.add('active');
            listViewBtn.classList.remove('active');
            boardView.classList.remove('d-none');
            listView.classList.add('d-none');
        });
    }
}

/**
 * Initialize create task modal
 */
function initCreateTaskModal() {
    const createTaskBtn = document.getElementById('createTaskBtn');
    const saveTaskBtn = document.getElementById('saveTaskBtn');
    const createTaskModal = document.getElementById('createTaskModal');
    const closeButtons = createTaskModal.querySelectorAll('[data-dismiss="modal"]');
    
    // Open modal
    if (createTaskBtn) {
        createTaskBtn.addEventListener('click', function() {
            openCreateTaskModal();
        });
    }
    
    // Close modal
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            createTaskModal.style.display = 'none';
        });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === createTaskModal) {
            createTaskModal.style.display = 'none';
        }
    });
    
    // Save task
    if (saveTaskBtn) {
        saveTaskBtn.addEventListener('click', function() {
            saveTask();
        });
    }
    
    // Load categories when project is selected
    const taskProject = document.getElementById('taskProject');
    if (taskProject) {
        taskProject.addEventListener('change', function() {
            const projectId = this.value;
            if (projectId) {
                loadCategoriesForProject(projectId);
            } else {
                // Clear categories
                const categorySelect = document.getElementById('taskCategory');
                categorySelect.innerHTML = '<option value="">No Category</option>';
            }
        });
    }
}

/**
 * Load categories for selected project
 * 
 * @param {number} projectId - Project ID
 */
function loadCategoriesForProject(projectId) {
    fetch(`api/categories/list.php?project_id=${projectId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const categorySelect = document.getElementById('taskCategory');
                
                // Clear existing options
                categorySelect.innerHTML = '<option value="">No Category</option>';
                
                // Add categories
                if (data.categories && data.categories.length > 0) {
                    data.categories.forEach(category => {
                        const option = document.createElement('option');
                        option.value = category.category_id;
                        option.textContent = category.name;
                        option.style.color = category.color || '#3498db';
                        categorySelect.appendChild(option);
                    });
                }
            } else {
                console.error('Failed to load categories:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading categories:', error);
        });
}

/**
 * Open create task modal
 */
function openCreateTaskModal() {
    const createTaskModal = document.getElementById('createTaskModal');
    const createTaskForm = document.getElementById('createTaskForm');
    
    // Reset form
    if (createTaskForm) {
        createTaskForm.reset();
    }
    
    // Set default values
    document.getElementById('taskStatus').value = 'to_do';
    document.getElementById('taskPriority').value = 'medium';
    
    // Set today as default start date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('taskStartDate').value = today;
    
    // Show modal
    createTaskModal.style.display = 'block';
}

/**
 * Save new task
 */
function saveTask() {
    // Get form values
    const title = document.getElementById('taskTitle').value;
    const projectId = document.getElementById('taskProject').value;
    const description = document.getElementById('taskDescription').value;
    const categoryId = document.getElementById('taskCategory').value;
    const status = document.getElementById('taskStatus').value;
    const priority = document.getElementById('taskPriority').value;
    const startDate = document.getElementById('taskStartDate').value;
    const dueDate = document.getElementById('taskDueDate').value;
    const assigneeId = document.getElementById('taskAssignee').value;
    const estimatedHours = document.getElementById('taskEstimatedHours').value;
    
    // Validate form
    if (!title) {
        showAlert('Task title is required', 'warning');
        return;
    }
    
    if (!projectId) {
        showAlert('Please select a project', 'warning');
        return;
    }
    
    // Create task data
    const taskData = {
        title: title,
        project_id: projectId,
        description: description,
        category_id: categoryId || null,
        status: status,
        priority: priority,
        start_date: startDate,
        due_date: dueDate,
        estimated_hours: estimatedHours || null,
        assigned_to: assigneeId || null
    };
    
    // Send request
    fetch('api/tasks/create.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(taskData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Close modal
            document.getElementById('createTaskModal').style.display = 'none';
            
            // Show success message
            showAlert('Task created successfully', 'success');
            
            // Reload tasks
            loadTasks();
        } else {
            showAlert(data.message || 'Failed to create task', 'danger');
        }
    })
    .catch(error => {
        console.error('Error creating task:', error);
        showAlert('An error occurred while creating the task', 'danger');
    });
}
