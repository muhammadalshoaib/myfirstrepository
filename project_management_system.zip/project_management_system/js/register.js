// Register page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize registration form
    initRegisterForm();
});

/**
 * Initialize registration form submission
 */
function initRegisterForm() {
    const registerForm = document.getElementById('registerForm');
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const fullName = document.getElementById('fullName').value;
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const termsAgreement = document.getElementById('termsAgreement').checked;
            
            // Validate form
            if (!fullName || !username || !email || !password || !confirmPassword) {
                showAlert('Please fill in all required fields', 'warning');
                return;
            }
            
            if (password !== confirmPassword) {
                showAlert('Passwords do not match', 'warning');
                return;
            }
            
            if (password.length < 8) {
                showAlert('Password must be at least 8 characters long', 'warning');
                return;
            }
            
            if (!termsAgreement) {
                showAlert('You must agree to the Terms of Service and Privacy Policy', 'warning');
                return;
            }
            
            // Submit registration request
            fetch('api/auth/register.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    full_name: fullName,
                    username: username,
                    email: email,
                    password: password
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Show success message
                    showAlert('Registration successful! Redirecting to login page...', 'success');
                    
                    // Redirect to login page after 2 seconds
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 2000);
                } else {
                    showAlert(data.message || 'Registration failed', 'danger');
                }
            })
            .catch(error => {
                console.error('Registration error:', error);
                showAlert('An error occurred during registration. Please try again.', 'danger');
            });
        });
    }
}
