// Login page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize login form
    initLoginForm();
});

/**
 * Initialize login form submission
 */
function initLoginForm() {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const rememberMe = document.getElementById('rememberMe').checked;
            
            // Validate form
            if (!username || !password) {
                showAlert('Please enter both username and password', 'warning');
                return;
            }
            
            // Submit login request
            fetch('api/auth/login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: username,
                    password: password,
                    remember_me: rememberMe
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Redirect to dashboard
                    window.location.href = 'index.php';
                } else {
                    showAlert(data.message || 'Login failed', 'danger');
                }
            })
            .catch(error => {
                console.error('Login error:', error);
                showAlert('An error occurred during login. Please try again.', 'danger');
            });
        });
    }
}
