// Dashboard specific JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Load dashboard data
    loadDashboardData();
    
    // Load recent projects
    loadRecentProjects();
    
    // Load recent tasks
    loadRecentTasks();
    
    // Load activity feed
    loadActivityFeed();
});

/**
 * Load dashboard statistics
 */
function loadDashboardData() {
    apiRequest('dashboard/stats.php')
        .then(data => {
            if (data.status === 'success') {
                // Update project count
                const projectCount = document.getElementById('projectCount');
                if (projectCount) {
                    projectCount.textContent = data.stats.projects || 0;
                }
                
                // Update task count
                const taskCount = document.getElementById('taskCount');
                if (taskCount) {
                    taskCount.textContent = data.stats.tasks || 0;
                }
                
                // Update completed task count
                const completedTaskCount = document.getElementById('completedTaskCount');
                if (completedTaskCount) {
                    completedTaskCount.textContent = data.stats.completed_tasks || 0;
                }
                
                // Update user count
                const userCount = document.getElementById('userCount');
                if (userCount) {
                    userCount.textContent = data.stats.users || 0;
                }
            } else {
                console.error('Failed to load dashboard stats:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading dashboard stats:', error);
        });
}

/**
 * Load recent projects
 */
function loadRecentProjects() {
    apiRequest('projects/recent.php')
        .then(data => {
            if (data.status === 'success') {
                const tableBody = document.getElementById('recentProjectsTable');
                if (!tableBody) return;
                
                // Clear existing content
                tableBody.innerHTML = '';
                
                if (data.projects && data.projects.length > 0) {
                    // Add projects to table
                    data.projects.forEach(project => {
                        const row = document.createElement('tr');
                        
                        // Project name
                        const nameCell = document.createElement('td');
                        const nameLink = document.createElement('a');
                        nameLink.href = `project-details.php?id=${project.project_id}`;
                        nameLink.textContent = project.name;
                        nameCell.appendChild(nameLink);
                        row.appendChild(nameCell);
                        
                        // Status
                        const statusCell = document.createElement('td');
                        const statusBadge = document.createElement('span');
                        statusBadge.className = `project-status status-${project.status.replace('_', '-')}`;
                        statusBadge.textContent = project.status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
                        statusCell.appendChild(statusBadge);
                        row.appendChild(statusCell);
                        
                        // Progress
                        const progressCell = document.createElement('td');
                        const progressContainer = document.createElement('div');
                        progressContainer.className = 'progress';
                        progressContainer.style.height = '5px';
                        
                        const progressBar = document.createElement('div');
                        progressBar.className = 'progress-bar bg-primary';
                        progressBar.style.width = `${project.progress || 0}%`;
                        progressBar.setAttribute('aria-valuenow', project.progress || 0);
                        progressBar.setAttribute('aria-valuemin', 0);
                        progressBar.setAttribute('aria-valuemax', 100);
                        
                        progressContainer.appendChild(progressBar);
                        progressCell.appendChild(progressContainer);
                        row.appendChild(progressCell);
                        
                        // Due date
                        const dueDateCell = document.createElement('td');
                        dueDateCell.textContent = formatDate(project.end_date);
                        row.appendChild(dueDateCell);
                        
                        // Actions
                        const actionsCell = document.createElement('td');
                        const viewBtn = document.createElement('a');
                        viewBtn.href = `project-details.php?id=${project.project_id}`;
                        viewBtn.className = 'btn btn-sm btn-info mr-1';
                        viewBtn.innerHTML = '<i class="fas fa-eye"></i>';
                        viewBtn.title = 'View Project';
                        
                        const editBtn = document.createElement('a');
                        editBtn.href = `edit-project.php?id=${project.project_id}`;
                        editBtn.className = 'btn btn-sm btn-warning mr-1';
                        editBtn.innerHTML = '<i class="fas fa-edit"></i>';
                        editBtn.title = 'Edit Project';
                        
                        actionsCell.appendChild(viewBtn);
                        actionsCell.appendChild(editBtn);
                        row.appendChild(actionsCell);
                        
                        tableBody.appendChild(row);
                    });
                } else {
                    // No projects
                    const row = document.createElement('tr');
                    const cell = document.createElement('td');
                    cell.colSpan = 5;
                    cell.textContent = 'No projects found';
                    cell.className = 'text-center';
                    row.appendChild(cell);
                    tableBody.appendChild(row);
                }
            } else {
                console.error('Failed to load recent projects:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading recent projects:', error);
        });
}

/**
 * Load recent tasks
 */
function loadRecentTasks() {
    apiRequest('tasks/recent.php')
        .then(data => {
            if (data.status === 'success') {
                const tasksList = document.getElementById('recentTasksList');
                if (!tasksList) return;
                
                // Clear existing content
                tasksList.innerHTML = '';
                
                if (data.tasks && data.tasks.length > 0) {
                    // Add tasks to list
                    data.tasks.forEach(task => {
                        const taskItem = document.createElement('div');
                        taskItem.className = 'task-item';
                        
                        // Checkbox
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.className = 'task-checkbox';
                        checkbox.checked = task.status === 'completed';
                        checkbox.dataset.taskId = task.task_id;
                        checkbox.addEventListener('change', function() {
                            updateTaskStatus(task.task_id, this.checked ? 'completed' : 'in_progress');
                        });
                        
                        // Task title
                        const title = document.createElement('div');
                        title.className = `task-title ${task.status === 'completed' ? 'completed' : ''}`;
                        
                        const titleLink = document.createElement('a');
                        titleLink.href = `task-details.php?id=${task.task_id}`;
                        titleLink.textContent = task.title;
                        
                        title.appendChild(titleLink);
                        
                        // Project badge
                        const projectBadge = document.createElement('span');
                        projectBadge.className = 'badge badge-info ml-2';
                        projectBadge.textContent = task.project_name;
                        title.appendChild(projectBadge);
                        
                        // Priority
                        const priority = document.createElement('div');
                        priority.className = `task-priority priority-${task.priority}`;
                        priority.innerHTML = `<i class="fas fa-flag"></i> ${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}`;
                        
                        // Due date
                        const dueDate = document.createElement('div');
                        dueDate.className = 'task-due-date';
                        dueDate.innerHTML = `<i class="far fa-calendar-alt"></i> ${formatDate(task.due_date)}`;
                        
                        // Actions
                        const actions = document.createElement('div');
                        actions.className = 'task-actions';
                        
                        const viewBtn = document.createElement('a');
                        viewBtn.href = `task-details.php?id=${task.task_id}`;
                        viewBtn.className = 'btn btn-sm btn-info';
                        viewBtn.innerHTML = '<i class="fas fa-eye"></i>';
                        viewBtn.title = 'View Task';
                        
                        const editBtn = document.createElement('a');
                        editBtn.href = `edit-task.php?id=${task.task_id}`;
                        editBtn.className = 'btn btn-sm btn-warning';
                        editBtn.innerHTML = '<i class="fas fa-edit"></i>';
                        editBtn.title = 'Edit Task';
                        
                        actions.appendChild(viewBtn);
                        actions.appendChild(editBtn);
                        
                        // Append all elements to task item
                        taskItem.appendChild(checkbox);
                        taskItem.appendChild(title);
                        taskItem.appendChild(priority);
                        taskItem.appendChild(dueDate);
                        taskItem.appendChild(actions);
                        
                        tasksList.appendChild(taskItem);
                    });
                } else {
                    // No tasks
                    const noTasks = document.createElement('div');
                    noTasks.className = 'text-center p-3';
                    noTasks.textContent = 'No tasks found';
                    tasksList.appendChild(noTasks);
                }
            } else {
                console.error('Failed to load recent tasks:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading recent tasks:', error);
        });
}

/**
 * Update task status
 * 
 * @param {number} taskId - Task ID
 * @param {string} status - New status
 */
function updateTaskStatus(taskId, status) {
    apiRequest('tasks/update-status.php', {
        method: 'POST',
        body: JSON.stringify({
            task_id: taskId,
            status: status
        })
    })
    .then(data => {
        if (data.status === 'success') {
            // Refresh tasks
            loadRecentTasks();
            // Refresh dashboard stats
            loadDashboardData();
        } else {
            console.error('Failed to update task status:', data.message);
            showAlert('Failed to update task status: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error updating task status:', error);
        showAlert('Error updating task status', 'danger');
    });
}

/**
 * Load activity feed
 */
function loadActivityFeed() {
    apiRequest('activity/recent.php')
        .then(data => {
            if (data.status === 'success') {
                const activityFeed = document.getElementById('activityFeed');
                if (!activityFeed) return;
                
                // Clear existing content
                activityFeed.innerHTML = '';
                
                if (data.activities && data.activities.length > 0) {
                    // Add activities to feed
                    data.activities.forEach(activity => {
                        const activityItem = document.createElement('li');
                        activityItem.className = 'mb-3';
                        
                        // Activity icon
                        const icon = document.createElement('i');
                        
                        // Set icon based on action type
                        switch (activity.action_type) {
                            case 'create':
                                icon.className = 'fas fa-plus-circle text-success';
                                break;
                            case 'update':
                                icon.className = 'fas fa-edit text-warning';
                                break;
                            case 'delete':
                                icon.className = 'fas fa-trash-alt text-danger';
                                break;
                            case 'add_member':
                                icon.className = 'fas fa-user-plus text-info';
                                break;
                            case 'remove_member':
                                icon.className = 'fas fa-user-minus text-danger';
                                break;
                            case 'add_comment':
                                icon.className = 'fas fa-comment-dots text-primary';
                                break;
                            case 'add_attachment':
                                icon.className = 'fas fa-paperclip text-info';
                                break;
                            case 'log_time':
                                icon.className = 'fas fa-clock text-warning';
                                break;
                            default:
                                icon.className = 'fas fa-info-circle text-primary';
                        }
                        
                        // Activity content
                        const content = document.createElement('div');
                        content.className = 'd-inline-block ml-2';
                        
                        // Activity description
                        const description = document.createElement('div');
                        description.innerHTML = `<strong>${activity.username}</strong> ${activity.description}`;
                        
                        // Activity time
                        const time = document.createElement('small');
                        time.className = 'text-muted';
                        time.textContent = formatDate(activity.created_at);
                        
                        content.appendChild(description);
                        content.appendChild(time);
                        
                        activityItem.appendChild(icon);
                        activityItem.appendChild(content);
                        
                        activityFeed.appendChild(activityItem);
                    });
                } else {
                    // No activities
                    const noActivities = document.createElement('li');
                    noActivities.className = 'text-center p-3';
                    noActivities.textContent = 'No recent activities';
                    activityFeed.appendChild(noActivities);
                }
            } else {
                console.error('Failed to load activity feed:', data.message);
            }
        })
        .catch(error => {
            console.error('Error loading activity feed:', error);
        });
}
