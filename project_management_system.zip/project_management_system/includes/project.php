<?php
/**
 * Project Management Class
 * 
 * Handles project creation, retrieval, updating, and deletion.
 */

class Project {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    /**
     * Create a new project
     * 
     * @param array $data Project data
     * @return array Response with status and message
     */
    public function create($data) {
        // Validate required fields
        if (empty($data['name']) || empty($data['owner_id'])) {
            return ['status' => 'error', 'message' => 'Project name and owner are required'];
        }
        
        // Prepare statement
        $stmt = $this->conn->prepare("
            INSERT INTO projects (name, description, start_date, end_date, status, owner_id) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        // Set default values if not provided
        $description = $data['description'] ?? '';
        $startDate = $data['start_date'] ?? null;
        $endDate = $data['end_date'] ?? null;
        $status = $data['status'] ?? 'planning';
        
        $stmt->bind_param("sssssi", 
            $data['name'], 
            $description, 
            $startDate, 
            $endDate, 
            $status, 
            $data['owner_id']
        );
        
        if ($stmt->execute()) {
            $projectId = $stmt->insert_id;
            
            // Add owner as project member with owner role
            $memberStmt = $this->conn->prepare("
                INSERT INTO project_members (project_id, user_id, role) 
                VALUES (?, ?, 'owner')
            ");
            $memberStmt->bind_param("ii", $projectId, $data['owner_id']);
            $memberStmt->execute();
            
            // Log activity
            $this->logActivity(
                $data['owner_id'],
                'create',
                'project',
                $projectId,
                "Created new project: {$data['name']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Project created successfully',
                'project_id' => $projectId
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to create project: ' . $stmt->error];
        }
    }
    
    /**
     * Get project by ID
     * 
     * @param int $projectId Project ID
     * @return array|null Project data or null if not found
     */
    public function getById($projectId) {
        $stmt = $this->conn->prepare("
            SELECT p.*, u.username as owner_username, u.full_name as owner_name
            FROM projects p
            JOIN users u ON p.owner_id = u.user_id
            WHERE p.project_id = ?
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        $project = $result->fetch_assoc();
        
        // Get project members
        $project['members'] = $this->getProjectMembers($projectId);
        
        return $project;
    }
    
    /**
     * Get all projects
     * 
     * @param array $filters Optional filters
     * @return array Array of projects
     */
    public function getAll($filters = []) {
        $sql = "
            SELECT p.*, u.username as owner_username, u.full_name as owner_name
            FROM projects p
            JOIN users u ON p.owner_id = u.user_id
        ";
        
        $whereConditions = [];
        $params = [];
        $types = "";
        
        // Apply filters
        if (!empty($filters['owner_id'])) {
            $whereConditions[] = "p.owner_id = ?";
            $params[] = $filters['owner_id'];
            $types .= "i";
        }
        
        if (!empty($filters['status'])) {
            $whereConditions[] = "p.status = ?";
            $params[] = $filters['status'];
            $types .= "s";
        }
        
        if (!empty($filters['user_id'])) {
            $sql .= " JOIN project_members pm ON p.project_id = pm.project_id";
            $whereConditions[] = "pm.user_id = ?";
            $params[] = $filters['user_id'];
            $types .= "i";
        }
        
        // Add WHERE clause if conditions exist
        if (!empty($whereConditions)) {
            $sql .= " WHERE " . implode(" AND ", $whereConditions);
        }
        
        // Add order by
        $sql .= " ORDER BY p.created_at DESC";
        
        $stmt = $this->conn->prepare($sql);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $projects = [];
        
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
        
        return $projects;
    }
    
    /**
     * Update project
     * 
     * @param int $projectId Project ID
     * @param array $data Project data to update
     * @return array Response with status and message
     */
    public function update($projectId, $data, $userId) {
        // Check if project exists and user has permission
        $project = $this->getById($projectId);
        
        if (!$project) {
            return ['status' => 'error', 'message' => 'Project not found'];
        }
        
        // Check if user is owner or has manager role
        $hasPermission = false;
        foreach ($project['members'] as $member) {
            if ($member['user_id'] == $userId && in_array($member['role'], ['owner', 'manager'])) {
                $hasPermission = true;
                break;
            }
        }
        
        if (!$hasPermission) {
            return ['status' => 'error', 'message' => 'You do not have permission to update this project'];
        }
        
        // Build update query
        $updateFields = [];
        $params = [];
        $types = "";
        
        if (isset($data['name'])) {
            $updateFields[] = "name = ?";
            $params[] = $data['name'];
            $types .= "s";
        }
        
        if (isset($data['description'])) {
            $updateFields[] = "description = ?";
            $params[] = $data['description'];
            $types .= "s";
        }
        
        if (isset($data['start_date'])) {
            $updateFields[] = "start_date = ?";
            $params[] = $data['start_date'];
            $types .= "s";
        }
        
        if (isset($data['end_date'])) {
            $updateFields[] = "end_date = ?";
            $params[] = $data['end_date'];
            $types .= "s";
        }
        
        if (isset($data['status'])) {
            $updateFields[] = "status = ?";
            $params[] = $data['status'];
            $types .= "s";
        }
        
        if (empty($updateFields)) {
            return ['status' => 'error', 'message' => 'No fields to update'];
        }
        
        // Add project ID to params
        $params[] = $projectId;
        $types .= "i";
        
        $sql = "UPDATE projects SET " . implode(", ", $updateFields) . " WHERE project_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        
        if ($stmt->execute()) {
            // Log activity
            $this->logActivity(
                $userId,
                'update',
                'project',
                $projectId,
                "Updated project: {$project['name']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Project updated successfully'
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to update project: ' . $stmt->error];
        }
    }
    
    /**
     * Delete project
     * 
     * @param int $projectId Project ID
     * @param int $userId User ID performing the deletion
     * @return array Response with status and message
     */
    public function delete($projectId, $userId) {
        // Check if project exists and user has permission
        $project = $this->getById($projectId);
        
        if (!$project) {
            return ['status' => 'error', 'message' => 'Project not found'];
        }
        
        // Only owner can delete project
        if ($project['owner_id'] != $userId) {
            return ['status' => 'error', 'message' => 'Only the project owner can delete this project'];
        }
        
        // Delete project
        $stmt = $this->conn->prepare("DELETE FROM projects WHERE project_id = ?");
        $stmt->bind_param("i", $projectId);
        
        if ($stmt->execute()) {
            // Log activity
            $this->logActivity(
                $userId,
                'delete',
                'project',
                $projectId,
                "Deleted project: {$project['name']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Project deleted successfully'
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to delete project: ' . $stmt->error];
        }
    }
    
    /**
     * Add member to project
     * 
     * @param int $projectId Project ID
     * @param int $userId User ID to add
     * @param string $role Member role
     * @param int $addedBy User ID adding the member
     * @return array Response with status and message
     */
    public function addMember($projectId, $userId, $role, $addedBy) {
        // Check if project exists
        $project = $this->getById($projectId);
        
        if (!$project) {
            return ['status' => 'error', 'message' => 'Project not found'];
        }
        
        // Check if user adding has permission (owner or manager)
        $hasPermission = false;
        foreach ($project['members'] as $member) {
            if ($member['user_id'] == $addedBy && in_array($member['role'], ['owner', 'manager'])) {
                $hasPermission = true;
                break;
            }
        }
        
        if (!$hasPermission) {
            return ['status' => 'error', 'message' => 'You do not have permission to add members to this project'];
        }
        
        // Check if user is already a member
        foreach ($project['members'] as $member) {
            if ($member['user_id'] == $userId) {
                return ['status' => 'error', 'message' => 'User is already a member of this project'];
            }
        }
        
        // Add member
        $stmt = $this->conn->prepare("
            INSERT INTO project_members (project_id, user_id, role) 
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iis", $projectId, $userId, $role);
        
        if ($stmt->execute()) {
            // Get user name
            $userStmt = $this->conn->prepare("SELECT username FROM users WHERE user_id = ?");
            $userStmt->bind_param("i", $userId);
            $userStmt->execute();
            $userResult = $userStmt->get_result();
            $user = $userResult->fetch_assoc();
            
            // Log activity
            $this->logActivity(
                $addedBy,
                'add_member',
                'project',
                $projectId,
                "Added {$user['username']} to project: {$project['name']} with role: $role"
            );
            
            return [
                'status' => 'success',
                'message' => 'Member added successfully'
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to add member: ' . $stmt->error];
        }
    }
    
    /**
     * Remove member from project
     * 
     * @param int $projectId Project ID
     * @param int $userId User ID to remove
     * @param int $removedBy User ID removing the member
     * @return array Response with status and message
     */
    public function removeMember($projectId, $userId, $removedBy) {
        // Check if project exists
        $project = $this->getById($projectId);
        
        if (!$project) {
            return ['status' => 'error', 'message' => 'Project not found'];
        }
        
        // Check if user removing has permission (owner or manager)
        $hasPermission = false;
        foreach ($project['members'] as $member) {
            if ($member['user_id'] == $removedBy && in_array($member['role'], ['owner', 'manager'])) {
                $hasPermission = true;
                break;
            }
        }
        
        if (!$hasPermission) {
            return ['status' => 'error', 'message' => 'You do not have permission to remove members from this project'];
        }
        
        // Cannot remove owner
        if ($project['owner_id'] == $userId) {
            return ['status' => 'error', 'message' => 'Cannot remove project owner'];
        }
        
        // Check if user is a member
        $isMember = false;
        foreach ($project['members'] as $member) {
            if ($member['user_id'] == $userId) {
                $isMember = true;
                break;
            }
        }
        
        if (!$isMember) {
            return ['status' => 'error', 'message' => 'User is not a member of this project'];
        }
        
        // Remove member
        $stmt = $this->conn->prepare("
            DELETE FROM project_members 
            WHERE project_id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $projectId, $userId);
        
        if ($stmt->execute()) {
            // Get user name
            $userStmt = $this->conn->prepare("SELECT username FROM users WHERE user_id = ?");
            $userStmt->bind_param("i", $userId);
            $userStmt->execute();
            $userResult = $userStmt->get_result();
            $user = $userResult->fetch_assoc();
            
            // Log activity
            $this->logActivity(
                $removedBy,
                'remove_member',
                'project',
                $projectId,
                "Removed {$user['username']} from project: {$project['name']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Member removed successfully'
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to remove member: ' . $stmt->error];
        }
    }
    
    /**
     * Get project members
     * 
     * @param int $projectId Project ID
     * @return array Array of project members
     */
    private function getProjectMembers($projectId) {
        $stmt = $this->conn->prepare("
            SELECT pm.*, u.username, u.full_name, u.email
            FROM project_members pm
            JOIN users u ON pm.user_id = u.user_id
            WHERE pm.project_id = ?
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result();
        $members = [];
        
        while ($row = $result->fetch_assoc()) {
            $members[] = $row;
        }
        
        return $members;
    }
    
    /**
     * Log activity
     * 
     * @param int $userId User ID
     * @param string $actionType Action type
     * @param string $entityType Entity type
     * @param int $entityId Entity ID
     * @param string $description Description
     */
    private function logActivity($userId, $actionType, $entityType, $entityId, $description) {
        $stmt = $this->conn->prepare("
            INSERT INTO activity_logs (user_id, action_type, entity_type, entity_id, description)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("issss", $userId, $actionType, $entityType, $entityId, $description);
        $stmt->execute();
    }
}
?>
