<?php
/**
 * Task Management Class
 * 
 * Handles task creation, retrieval, updating, and deletion.
 */

class Task {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    /**
     * Create a new task
     * 
     * @param array $data Task data
     * @return array Response with status and message
     */
    public function create($data) {
        // Validate required fields
        if (empty($data['project_id']) || empty($data['title']) || empty($data['created_by'])) {
            return ['status' => 'error', 'message' => 'Project ID, title, and creator are required'];
        }
        
        // Prepare statement
        $stmt = $this->conn->prepare("
            INSERT INTO tasks (
                project_id, title, description, category_id, status, 
                priority, start_date, due_date, estimated_hours, 
                created_by, assigned_to
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Set default values if not provided
        $description = $data['description'] ?? '';
        $categoryId = $data['category_id'] ?? null;
        $status = $data['status'] ?? 'to_do';
        $priority = $data['priority'] ?? 'medium';
        $startDate = $data['start_date'] ?? null;
        $dueDate = $data['due_date'] ?? null;
        $estimatedHours = $data['estimated_hours'] ?? null;
        $assignedTo = $data['assigned_to'] ?? null;
        
        $stmt->bind_param("issiisssdii", 
            $data['project_id'], 
            $data['title'], 
            $description, 
            $categoryId, 
            $status, 
            $priority, 
            $startDate, 
            $dueDate, 
            $estimatedHours, 
            $data['created_by'], 
            $assignedTo
        );
        
        if ($stmt->execute()) {
            $taskId = $stmt->insert_id;
            
            // Log activity
            $this->logActivity(
                $data['created_by'],
                'create',
                'task',
                $taskId,
                "Created new task: {$data['title']}"
            );
            
            // Create notification for assigned user if any
            if ($assignedTo) {
                $this->createNotification(
                    $assignedTo,
                    "New Task Assigned",
                    "You have been assigned to task: {$data['title']}",
                    'task',
                    $taskId
                );
            }
            
            return [
                'status' => 'success',
                'message' => 'Task created successfully',
                'task_id' => $taskId
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to create task: ' . $stmt->error];
        }
    }
    
    /**
     * Get task by ID
     * 
     * @param int $taskId Task ID
     * @return array|null Task data or null if not found
     */
    public function getById($taskId) {
        $stmt = $this->conn->prepare("
            SELECT t.*, 
                p.name as project_name,
                c.name as category_name,
                c.color as category_color,
                creator.username as creator_username,
                creator.full_name as creator_name,
                assignee.username as assignee_username,
                assignee.full_name as assignee_name
            FROM tasks t
            JOIN projects p ON t.project_id = p.project_id
            LEFT JOIN task_categories c ON t.category_id = c.category_id
            JOIN users creator ON t.created_by = creator.user_id
            LEFT JOIN users assignee ON t.assigned_to = assignee.user_id
            WHERE t.task_id = ?
        ");
        $stmt->bind_param("i", $taskId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        $task = $result->fetch_assoc();
        
        // Get task comments
        $task['comments'] = $this->getTaskComments($taskId);
        
        // Get task attachments
        $task['attachments'] = $this->getTaskAttachments($taskId);
        
        return $task;
    }
    
    /**
     * Get all tasks
     * 
     * @param array $filters Optional filters
     * @return array Array of tasks
     */
    public function getAll($filters = []) {
        $sql = "
            SELECT t.*, 
                p.name as project_name,
                c.name as category_name,
                c.color as category_color,
                creator.username as creator_username,
                creator.full_name as creator_name,
                assignee.username as assignee_username,
                assignee.full_name as assignee_name
            FROM tasks t
            JOIN projects p ON t.project_id = p.project_id
            LEFT JOIN task_categories c ON t.category_id = c.category_id
            JOIN users creator ON t.created_by = creator.user_id
            LEFT JOIN users assignee ON t.assigned_to = assignee.user_id
        ";
        
        $whereConditions = [];
        $params = [];
        $types = "";
        
        // Apply filters
        if (!empty($filters['project_id'])) {
            $whereConditions[] = "t.project_id = ?";
            $params[] = $filters['project_id'];
            $types .= "i";
        }
        
        if (!empty($filters['category_id'])) {
            $whereConditions[] = "t.category_id = ?";
            $params[] = $filters['category_id'];
            $types .= "i";
        }
        
        if (!empty($filters['status'])) {
            $whereConditions[] = "t.status = ?";
            $params[] = $filters['status'];
            $types .= "s";
        }
        
        if (!empty($filters['priority'])) {
            $whereConditions[] = "t.priority = ?";
            $params[] = $filters['priority'];
            $types .= "s";
        }
        
        if (!empty($filters['created_by'])) {
            $whereConditions[] = "t.created_by = ?";
            $params[] = $filters['created_by'];
            $types .= "i";
        }
        
        if (!empty($filters['assigned_to'])) {
            $whereConditions[] = "t.assigned_to = ?";
            $params[] = $filters['assigned_to'];
            $types .= "i";
        }
        
        if (!empty($filters['due_date_from'])) {
            $whereConditions[] = "t.due_date >= ?";
            $params[] = $filters['due_date_from'];
            $types .= "s";
        }
        
        if (!empty($filters['due_date_to'])) {
            $whereConditions[] = "t.due_date <= ?";
            $params[] = $filters['due_date_to'];
            $types .= "s";
        }
        
        // Add WHERE clause if conditions exist
        if (!empty($whereConditions)) {
            $sql .= " WHERE " . implode(" AND ", $whereConditions);
        }
        
        // Add order by
        $orderBy = !empty($filters['order_by']) ? $filters['order_by'] : 'created_at';
        $orderDir = !empty($filters['order_dir']) ? $filters['order_dir'] : 'DESC';
        $sql .= " ORDER BY t.$orderBy $orderDir";
        
        $stmt = $this->conn->prepare($sql);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $tasks = [];
        
        while ($row = $result->fetch_assoc()) {
            $tasks[] = $row;
        }
        
        return $tasks;
    }
    
    /**
     * Update task
     * 
     * @param int $taskId Task ID
     * @param array $data Task data to update
     * @param int $userId User ID performing the update
     * @return array Response with status and message
     */
    public function update($taskId, $data, $userId) {
        // Check if task exists
        $task = $this->getById($taskId);
        
        if (!$task) {
            return ['status' => 'error', 'message' => 'Task not found'];
        }
        
        // Check if user has permission to update task
        $projectObj = new Project();
        $project = $projectObj->getById($task['project_id']);
        
        $hasPermission = false;
        
        // Creator or assignee can update task
        if ($task['created_by'] == $userId || $task['assigned_to'] == $userId) {
            $hasPermission = true;
        } else {
            // Project owner or manager can update task
            foreach ($project['members'] as $member) {
                if ($member['user_id'] == $userId && in_array($member['role'], ['owner', 'manager'])) {
                    $hasPermission = true;
                    break;
                }
            }
        }
        
        if (!$hasPermission) {
            return ['status' => 'error', 'message' => 'You do not have permission to update this task'];
        }
        
        // Build update query
        $updateFields = [];
        $params = [];
        $types = "";
        
        if (isset($data['title'])) {
            $updateFields[] = "title = ?";
            $params[] = $data['title'];
            $types .= "s";
        }
        
        if (isset($data['description'])) {
            $updateFields[] = "description = ?";
            $params[] = $data['description'];
            $types .= "s";
        }
        
        if (isset($data['category_id'])) {
            $updateFields[] = "category_id = ?";
            $params[] = $data['category_id'];
            $types .= "i";
        }
        
        if (isset($data['status'])) {
            $updateFields[] = "status = ?";
            $params[] = $data['status'];
            $types .= "s";
        }
        
        if (isset($data['priority'])) {
            $updateFields[] = "priority = ?";
            $params[] = $data['priority'];
            $types .= "s";
        }
        
        if (isset($data['start_date'])) {
            $updateFields[] = "start_date = ?";
            $params[] = $data['start_date'];
            $types .= "s";
        }
        
        if (isset($data['due_date'])) {
            $updateFields[] = "due_date = ?";
            $params[] = $data['due_date'];
            $types .= "s";
        }
        
        if (isset($data['estimated_hours'])) {
            $updateFields[] = "estimated_hours = ?";
            $params[] = $data['estimated_hours'];
            $types .= "d";
        }
        
        if (isset($data['assigned_to'])) {
            $updateFields[] = "assigned_to = ?";
            $params[] = $data['assigned_to'];
            $types .= "i";
            
            // Create notification for newly assigned user
            if ($data['assigned_to'] && $data['assigned_to'] != $task['assigned_to']) {
                $this->createNotification(
                    $data['assigned_to'],
                    "Task Assigned",
                    "You have been assigned to task: {$task['title']}",
                    'task',
                    $taskId
                );
            }
        }
        
        if (empty($updateFields)) {
            return ['status' => 'error', 'message' => 'No fields to update'];
        }
        
        // Add task ID to params
        $params[] = $taskId;
        $types .= "i";
        
        $sql = "UPDATE tasks SET " . implode(", ", $updateFields) . " WHERE task_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        
        if ($stmt->execute()) {
            // Log activity
            $this->logActivity(
                $userId,
                'update',
                'task',
                $taskId,
                "Updated task: {$task['title']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Task updated successfully'
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to update task: ' . $stmt->error];
        }
    }
    
    /**
     * Delete task
     * 
     * @param int $taskId Task ID
     * @param int $userId User ID performing the deletion
     * @return array Response with status and message
     */
    public function delete($taskId, $userId) {
        // Check if task exists
        $task = $this->getById($taskId);
        
        if (!$task) {
            return ['status' => 'error', 'message' => 'Task not found'];
        }
        
        // Check if user has permission to delete task
        $projectObj = new Project();
        $project = $projectObj->getById($task['project_id']);
        
        $hasPermission = false;
        
        // Creator can delete task
        if ($task['created_by'] == $userId) {
            $hasPermission = true;
        } else {
            // Project owner or manager can delete task
            foreach ($project['members'] as $member) {
                if ($member['user_id'] == $userId && in_array($member['role'], ['owner', 'manager'])) {
                    $hasPermission = true;
                    break;
                }
            }
        }
        
        if (!$hasPermission) {
            return ['status' => 'error', 'message' => 'You do not have permission to delete this task'];
        }
        
        // Delete task
        $stmt = $this->conn->prepare("DELETE FROM tasks WHERE task_id = ?");
        $stmt->bind_param("i", $taskId);
        
        if ($stmt->execute()) {
            // Log activity
            $this->logActivity(
                $userId,
                'delete',
                'task',
                $taskId,
                "Deleted task: {$task['title']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Task deleted successfully'
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to delete task: ' . $stmt->error];
        }
    }
    
    /**
     * Add comment to task
     * 
     * @param int $taskId Task ID
     * @param int $userId User ID adding the comment
     * @param string $comment Comment text
     * @return array Response with status and message
     */
    public function addComment($taskId, $userId, $comment) {
        // Check if task exists
        $task = $this->getById($taskId);
        
        if (!$task) {
            return ['status' => 'error', 'message' => 'Task not found'];
        }
        
        // Add comment
        $stmt = $this->conn->prepare("
            INSERT INTO task_comments (task_id, user_id, comment)
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iis", $taskId, $userId, $comment);
        
        if ($stmt->execute()) {
            $commentId = $stmt->insert_id;
            
            // Log activity
            $this->logActivity(
                $userId,
                'add_comment',
                'task',
                $taskId,
                "Added comment to task: {$task['title']}"
            );
            
            // Notify task creator and assignee (if different from commenter)
            if ($task['created_by'] != $userId) {
                $this->createNotification(
                    $task['created_by'],
                    "New Comment on Task",
                    "New comment on task: {$task['title']}",
                    'comment',
                    $commentId
                );
            }
            
            if ($task['assigned_to'] && $task['assigned_to'] != $userId && $task['assigned_to'] != $task['created_by']) {
                $this->createNotification(
                    $task['assigned_to'],
                    "New Comment on Task",
                    "New comment on task: {$task['title']}",
                    'comment',
                    $commentId
                );
            }
            
            return [
                'status' => 'success',
                'message' => 'Comment added successfully',
                'comment_id' => $commentId
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to add comment: ' . $stmt->error];
        }
    }
    
    /**
     * Add attachment to task
     * 
     * @param int $taskId Task ID
     * @param int $userId User ID adding the attachment
     * @param array $fileData File data
     * @return array Response with status and message
     */
    public function addAttachment($taskId, $userId, $fileData) {
        // Check if task exists
        $task = $this->getById($taskId);
        
        if (!$task) {
            return ['status' => 'error', 'message' => 'Task not found'];
        }
        
        // Add attachment
        $stmt = $this->conn->prepare("
            INSERT INTO task_attachments (task_id, user_id, file_name, file_path, file_type, file_size)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("iisssi", 
            $taskId, 
            $userId, 
            $fileData['file_name'], 
            $fileData['file_path'], 
            $fileData['file_type'], 
            $fileData['file_size']
        );
        
        if ($stmt->execute()) {
            $attachmentId = $stmt->insert_id;
            
            // Log activity
            $this->logActivity(
                $userId,
                'add_attachment',
                'task',
                $taskId,
                "Added attachment to task: {$task['title']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Attachment added successfully',
                'attachment_id' => $attachmentId
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to add attachment: ' . $stmt->error];
        }
    }
    
    /**
     * Log time spent on task
     * 
     * @param int $taskId Task ID
     * @param int $userId User ID logging time
     * @param float $hoursSpent Hours spent
     * @param string $logDate Date of time spent
     * @param string $description Description of work done
     * @return array Response with status and message
     */
    public function logTime($taskId, $userId, $hoursSpent, $logDate, $description = '') {
        // Check if task exists
        $task = $this->getById($taskId);
        
        if (!$task) {
            return ['status' => 'error', 'message' => 'Task not found'];
        }
        
        // Log time
        $stmt = $this->conn->prepare("
            INSERT INTO task_time_logs (task_id, user_id, hours_spent, log_date, description)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("iidss", $taskId, $userId, $hoursSpent, $logDate, $description);
        
        if ($stmt->execute()) {
            $logId = $stmt->insert_id;
            
            // Log activity
            $this->logActivity(
                $userId,
                'log_time',
                'task',
                $taskId,
                "Logged $hoursSpent hours on task: {$task['title']}"
            );
            
            return [
                'status' => 'success',
                'message' => 'Time logged successfully',
                'log_id' => $logId
            ];
        } else {
            return ['status' => 'error', 'message' => 'Failed to log time: ' . $stmt->error];
        }
    }
    
    /**
     * Get task comments
     * 
     * @param int $taskId Task ID
     * @return array Array of comments
     */
    private function getTaskComments($taskId) {
        $stmt = $this->conn->prepare("
            SELECT tc.*, u.username, u.full_name
            FROM task_comments tc
            JOIN users u ON tc.user_id = u.user_id
            WHERE tc.task_id = ?
            ORDER BY tc.created_at ASC
        ");
        $stmt->bind_param("i", $taskId);
        $stmt->execute();
        $result = $stmt->get_result();
        $comments = [];
        
        while ($row = $result->fetch_assoc()) {
            $comments[] = $row;
        }
        
        return $comments;
    }
    
    /**
     * Get task attachments
     * 
     * @param int $taskId Task ID
     * @return array Array of attachments
     */
    private function getTaskAttachments($taskId) {
        $stmt = $this->conn->prepare("
            SELECT ta.*, u.username, u.full_name
            FROM task_attachments ta
            JOIN users u ON ta.user_id = u.user_id
            WHERE ta.task_id = ?
            ORDER BY ta.uploaded_at DESC
        ");
        $stmt->bind_param("i", $taskId);
        $stmt->execute();
        $result = $stmt->get_result();
        $attachments = [];
        
        while ($row = $result->fetch_assoc()) {
            $attachments[] = $row;
        }
        
        return $attachments;
    }
    
    /**
     * Log activity
     * 
     * @param int $userId User ID
     * @param string $actionType Action type
     * @param string $entityType Entity type
     * @param int $entityId Entity ID
     * @param string $description Description
     */
    private function logActivity($userId, $actionType, $entityType, $entityId, $description) {
        $stmt = $this->conn->prepare("
            INSERT INTO activity_logs (user_id, action_type, entity_type, entity_id, description)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("issss", $userId, $actionType, $entityType, $entityId, $description);
        $stmt->execute();
    }
    
    /**
     * Create notification
     * 
     * @param int $userId User ID to notify
     * @param string $title Notification title
     * @param string $message Notification message
     * @param string $relatedTo Related entity type
     * @param int $relatedId Related entity ID
     */
    private function createNotification($userId, $title, $message, $relatedTo, $relatedId) {
        $stmt = $this->conn->prepare("
            INSERT INTO notifications (user_id, title, message, related_to, related_id)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("isssi", $userId, $title, $message, $relatedTo, $relatedId);
        $stmt->execute();
    }
}
?>
