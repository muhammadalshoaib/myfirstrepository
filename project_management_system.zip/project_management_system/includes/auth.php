<?php
/**
 * User Authentication Class
 * 
 * Handles user registration, login, logout, and session management.
 */

class Auth {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    /**
     * Register a new user
     * 
     * @param string $username Username
     * @param string $password Password
     * @param string $email Email address
     * @param string $fullName Full name
     * @param string $role User role (default: member)
     * @return array Response with status and message
     */
    public function register($username, $password, $email, $fullName, $role = 'member') {
        // Validate input
        if (empty($username) || empty($password) || empty($email) || empty($fullName)) {
            return ['status' => 'error', 'message' => 'All fields are required'];
        }
        
        // Check if username or email already exists
        $stmt = $this->conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return ['status' => 'error', 'message' => 'Username or email already exists'];
        }
        
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        
        // Insert new user
        $stmt = $this->conn->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $hashedPassword, $email, $fullName, $role);
        
        if ($stmt->execute()) {
            return [
                'status' => 'success', 
                'message' => 'User registered successfully',
                'user_id' => $stmt->insert_id
            ];
        } else {
            return ['status' => 'error', 'message' => 'Registration failed: ' . $stmt->error];
        }
    }
    
    /**
     * Login user
     * 
     * @param string $username Username or email
     * @param string $password Password
     * @return array Response with status and message
     */
    public function login($username, $password) {
        // Validate input
        if (empty($username) || empty($password)) {
            return ['status' => 'error', 'message' => 'Username and password are required'];
        }
        
        // Check if input is email or username
        $field = filter_var($username, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        
        // Get user
        $stmt = $this->conn->prepare("SELECT user_id, username, password, email, full_name, role FROM users WHERE $field = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return ['status' => 'error', 'message' => 'Invalid username or password'];
        }
        
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Start session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            
            // Remove password from user array
            unset($user['password']);
            
            return [
                'status' => 'success',
                'message' => 'Login successful',
                'user' => $user
            ];
        } else {
            return ['status' => 'error', 'message' => 'Invalid username or password'];
        }
    }
    
    /**
     * Logout user
     * 
     * @return array Response with status and message
     */
    public function logout() {
        // Unset all session variables
        $_SESSION = [];
        
        // Destroy the session
        session_destroy();
        
        return ['status' => 'success', 'message' => 'Logout successful'];
    }
    
    /**
     * Check if user is logged in
     * 
     * @return bool True if logged in, false otherwise
     */
    public function isLoggedIn() {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }
    
    /**
     * Get current user data
     * 
     * @return array|null User data or null if not logged in
     */
    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        
        return [
            'user_id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'email' => $_SESSION['email'],
            'full_name' => $_SESSION['full_name'],
            'role' => $_SESSION['role']
        ];
    }
    
    /**
     * Check if current user has specific role
     * 
     * @param string|array $roles Role or array of roles to check
     * @return bool True if user has role, false otherwise
     */
    public function hasRole($roles) {
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        if (is_array($roles)) {
            return in_array($_SESSION['role'], $roles);
        }
        
        return $_SESSION['role'] === $roles;
    }
}
?>
