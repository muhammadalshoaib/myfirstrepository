# Project Management System - User Guide

## Introduction

Welcome to the Project Management System! This comprehensive tool helps teams organize, track, and manage projects and tasks efficiently. This guide will walk you through the main features and functionality of the system.

## Getting Started

### Logging In

1. Navigate to the login page at `http://your-domain.com/project_management_system/login.php`
2. Enter your username or email and password
3. Click the "Login" button

If you don't have an account, click the "Register" link to create one.

### Dashboard Overview

After logging in, you'll be directed to the dashboard, which provides:

- Summary statistics (total projects, tasks, completed tasks, team members)
- Recent projects with progress indicators
- Recent tasks assigned to you
- Activity feed showing recent actions across your projects

## Managing Projects

### Viewing Projects

1. Click on "Projects" in the main navigation menu
2. Browse the list of projects displayed as cards
3. Use filters at the top to sort and search for specific projects

### Creating a New Project

1. Click the "Create Project" button on the Projects page
2. Fill in the project details:
   - Project Name (required)
   - Description
   - Start Date
   - End Date
   - Status (Planning, In Progress, On Hold, Completed, Cancelled)
3. Click "Create Project" to save

### Project Details

Click on a project card to view its details page, which includes:

- Project information and progress
- Task list for the project
- Team members
- Project activity

### Editing a Project

1. From the project details page, click the "Edit" button
2. Update the project information as needed
3. Click "Save Changes"

### Managing Project Members

1. From the project details page, click the "Team" tab
2. To add a member:
   - Click "Add Member"
   - Select a user from the dropdown
   - Assign a role (Owner, Manager, Member)
   - Click "Add"
3. To remove a member:
   - Find the member in the list
   - Click the "Remove" button next to their name

## Managing Tasks

### Viewing Tasks

1. Click on "Tasks" in the main navigation menu
2. Browse tasks in either List or Board view (toggle using the buttons at the top)
3. Use filters to sort and search for specific tasks

### Creating a New Task

1. Click the "Create Task" button on the Tasks page
2. Fill in the task details:
   - Task Title (required)
   - Project (required)
   - Description
   - Category (if applicable)
   - Status (To Do, In Progress, Review, Completed)
   - Priority (Low, Medium, High, Urgent)
   - Start Date
   - Due Date
   - Assignee
   - Estimated Hours
3. Click "Create Task" to save

### Task Details

Click on a task to view its details page, which includes:

- Task information
- Description
- Comments
- Attachments
- Time logs

### Updating Task Status

There are two ways to update a task's status:

1. From the task list, click the checkbox next to a task to mark it as completed
2. From the task details page, change the status dropdown and click "Save"

### Adding Comments

1. From the task details page, scroll to the Comments section
2. Type your comment in the text box
3. Click "Add Comment"

### Uploading Attachments

1. From the task details page, go to the Attachments section
2. Click "Add Attachment"
3. Select a file from your computer
4. Click "Upload"

### Logging Time

1. From the task details page, go to the Time Logs section
2. Click "Log Time"
3. Enter the hours spent, date, and description
4. Click "Save"

## User Management

### Viewing Users

1. Click on "Users" in the main navigation menu (admin only)
2. Browse the list of users

### Adding a New User

1. Click "Add User" on the Users page (admin only)
2. Fill in the user details:
   - Full Name
   - Username
   - Email
   - Password
   - Role
3. Click "Add User" to save

### Editing User Profiles

1. From the Users page, click on a user's name (admin only)
2. Update the user information as needed
3. Click "Save Changes"

### Managing Your Profile

1. Click on your username in the top navigation bar
2. Select "Profile" from the dropdown
3. Update your information as needed
4. Click "Save Changes"

## Reports

### Generating Reports

1. Click on "Reports" in the main navigation menu
2. Select the type of report you want to generate:
   - Project Progress
   - Task Completion
   - Time Tracking
   - User Activity
3. Set the date range and other filters
4. Click "Generate Report"

### Exporting Reports

1. After generating a report, click the "Export" button
2. Choose your preferred format (PDF, CSV, Excel)
3. Save the file to your computer

## Settings

### Application Settings

1. Click on "Settings" in the main navigation menu (admin only)
2. Adjust system-wide settings as needed
3. Click "Save Changes"

### Notification Settings

1. Click on your username in the top navigation bar
2. Select "Settings" from the dropdown
3. Go to the "Notifications" tab
4. Configure your notification preferences
5. Click "Save"

## Logging Out

1. Click on your username in the top navigation bar
2. Select "Logout" from the dropdown

## Keyboard Shortcuts

- `Shift + P`: Go to Projects
- `Shift + T`: Go to Tasks
- `Shift + D`: Go to Dashboard
- `Shift + N`: Create new task
- `Shift + ?`: Show keyboard shortcuts

## Tips and Best Practices

1. **Regular Updates**: Keep task statuses up to date for accurate project progress tracking
2. **Task Descriptions**: Write clear, detailed task descriptions to avoid confusion
3. **Due Dates**: Set realistic due dates and update them if circumstances change
4. **Comments**: Use comments to document decisions and progress
5. **Time Tracking**: Log time consistently for accurate reporting
6. **Attachments**: Attach relevant files to keep all project information in one place
7. **Categories**: Use task categories to organize and filter tasks effectively

## Troubleshooting

### Common Issues

1. **Can't see a project**: Verify you have been added as a member to the project
2. **Can't edit a task**: Check if you have the necessary permissions (creator, assignee, or project manager/owner)
3. **Missing notifications**: Check your notification settings and ensure your email is correct

For additional support or questions, please contact your system administrator.
