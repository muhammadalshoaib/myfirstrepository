<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects - Project Management System</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="navbar-brand">Project Management System</a>
            <div class="navbar-nav" id="navbarNav">
                <div class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link active" href="projects.php">Projects</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="tasks.php">Tasks</a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="users.php">Users</a>
                </div>
                <div class="nav-item" id="userDropdown">
                    <a class="nav-link" href="#"><i class="fas fa-user"></i> <span id="currentUser">User</span></a>
                    <div class="dropdown-menu d-none" id="userMenu">
                        <a href="profile.php">Profile</a>
                        <a href="settings.php">Settings</a>
                        <a href="#" id="logoutBtn">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-3">
                <div class="sidebar">
                    <div class="sidebar-sticky">
                        <h6 class="sidebar-heading">Main Menu</h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">
                                    <i class="fas fa-home"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="projects.php">
                                    <i class="fas fa-project-diagram"></i> Projects
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="tasks.php">
                                    <i class="fas fa-tasks"></i> Tasks
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="calendar.php">
                                    <i class="fas fa-calendar-alt"></i> Calendar
                                </a>
                            </li>
                        </ul>

                        <h6 class="sidebar-heading mt-4">Management</h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i class="fas fa-users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="reports.php">
                                    <i class="fas fa-chart-bar"></i> Reports
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="settings.php">
                                    <i class="fas fa-cog"></i> Settings
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Main Content Area -->
            <div class="col-9">
                <div class="main-content">
                    <div id="alertContainer"></div>
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1>Projects</h1>
                        <button class="btn btn-primary" id="createProjectBtn">
                            <i class="fas fa-plus"></i> Create Project
                        </button>
                    </div>

                    <!-- Project Filters -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Filters</h5>
                        </div>
                        <div class="card-body">
                            <form id="projectFilterForm" class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="statusFilter">Status</label>
                                        <select class="form-control" id="statusFilter">
                                            <option value="">All Statuses</option>
                                            <option value="planning">Planning</option>
                                            <option value="in_progress">In Progress</option>
                                            <option value="on_hold">On Hold</option>
                                            <option value="completed">Completed</option>
                                            <option value="cancelled">Cancelled</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="sortBy">Sort By</label>
                                        <select class="form-control" id="sortBy">
                                            <option value="created_at">Date Created</option>
                                            <option value="name">Name</option>
                                            <option value="end_date">Due Date</option>
                                            <option value="status">Status</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="searchProject">Search</label>
                                        <input type="text" class="form-control" id="searchProject" placeholder="Search projects...">
                                    </div>
                                </div>
                                <div class="col-12 text-right">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-filter"></i> Apply Filters
                                    </button>
                                    <button type="button" class="btn btn-secondary" id="resetFiltersBtn">
                                        <i class="fas fa-undo"></i> Reset
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Projects List -->
                    <div class="row" id="projectsList">
                        <!-- Projects will be loaded here via JavaScript -->
                        <div class="col-12 text-center py-5">
                            <div class="spinner-border text-primary" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                            <p class="mt-2">Loading projects...</p>
                        </div>
                    </div>

                    <!-- Pagination -->
                    <nav aria-label="Projects pagination" class="mt-4">
                        <ul class="pagination justify-content-center" id="projectsPagination">
                            <!-- Pagination will be generated via JavaScript -->
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Project Modal -->
    <div class="modal" id="createProjectModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Project</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="createProjectForm">
                        <div class="form-group">
                            <label for="projectName">Project Name</label>
                            <input type="text" class="form-control" id="projectName" required>
                        </div>
                        <div class="form-group">
                            <label for="projectDescription">Description</label>
                            <textarea class="form-control" id="projectDescription" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="projectStartDate">Start Date</label>
                            <input type="date" class="form-control" id="projectStartDate">
                        </div>
                        <div class="form-group">
                            <label for="projectEndDate">End Date</label>
                            <input type="date" class="form-control" id="projectEndDate">
                        </div>
                        <div class="form-group">
                            <label for="projectStatus">Status</label>
                            <select class="form-control" id="projectStatus">
                                <option value="planning">Planning</option>
                                <option value="in_progress">In Progress</option>
                                <option value="on_hold">On Hold</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveProjectBtn">Create Project</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">Project Management System &copy; 2025. All rights reserved.</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="js/main.js"></script>
    <script src="js/projects.js"></script>
</body>
</html>
